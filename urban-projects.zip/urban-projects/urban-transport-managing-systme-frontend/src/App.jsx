import { useEffect, useRef, useState, Fragment, useMemo, useCallback } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import "./App.css";
import "leaflet/dist/leaflet.css";
import { MapContainer, TileLayer, Marker, Popup, Polyline, CircleMarker, useMap } from "react-leaflet";

const API_BASE = "http://localhost:8000";

const ROUTE_MAP_COLORS = ["#e74c3c", "#3498db", "#2ecc71", "#f39c12", "#9b59b6"];
const DEFAULT_MAP_CENTER = [50.4501, 30.5234];
const SEARCH_ROUTE_LINE_COLOR = "#8B0000";
const CHAT_TOAST_CHANNEL = "utms-chat-toasts";

function getChatToastId(payload) {
    return `chat-${payload.conversation_id ?? "x"}-${payload.sent_at ?? ""}-${payload.sender_id ?? ""}`;
}
function App() {
    const [token, setToken] = useState(localStorage.getItem("token"));
    const [view, setView] = useState(token ? "routes" : "auth");
    const [authMode, setAuthMode] = useState("login");
    const [authLoading, setAuthLoading] = useState(false);
    const [authError, setAuthError] = useState("");

    const handleLogin = async (e) => {
        e.preventDefault();
        setAuthError("");
        setAuthLoading(true);
        const form = new FormData(e.target);
        const body = new URLSearchParams();
        body.append("username", form.get("email"));
        body.append("password", form.get("password"));

        try {
            const res = await fetch(`${API_BASE}/login`, {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body,
            });
            const data = await res.json();
            if (res.ok) {
                localStorage.setItem("token", data.access_token);
                setToken(data.access_token);
                setView("routes");
            } else {
                setAuthError(data.detail || "Помилка входу");
            }
        } catch (err) {
            console.error(err);
            setAuthError("Помилка з'єднання з сервером");
        } finally {
            setAuthLoading(false);
        }
    };

    const handleRegister = async (e) => {
        e.preventDefault();
        setAuthError("");
        setAuthLoading(true);
        const form = new FormData(e.target);
        const payload = {
            email: form.get("email"),
            password: form.get("password"),
            username: form.get("username"),
        };

        try {
            const res = await fetch(`${API_BASE}/register`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload),
            });
            const data = await res.json();
            if (res.ok) {
                setAuthMode("login");
                setAuthError("");
                alert("Реєстрація успішна! Увійдіть у систему.");
            } else {
                setAuthError(data.detail || "Помилка реєстрації");
            }
        } catch (err) {
            console.error(err);
            setAuthError("Помилка з'єднання з сервером");
        } finally {
            setAuthLoading(false);
        }
    };

    const handleLogout = () => {
        localStorage.removeItem("token");
        setToken(null);
        setView("auth");
    };

    if (view === "auth") {
        return (
            <div className="auth-page">
                <aside className="auth-brand">
                    <div className="auth-brand-content">
                        <div className="auth-logo">
                            <svg viewBox="0 0 48 48" width="48" height="48" aria-hidden="true">
                                <rect x="6" y="14" width="36" height="22" rx="4" fill="currentColor" opacity="0.9" />
                                <rect x="10" y="18" width="10" height="8" rx="1.5" fill="#0d2137" />
                                <rect x="28" y="18" width="10" height="8" rx="1.5" fill="#0d2137" />
                                <circle cx="14" cy="38" r="4" fill="currentColor" />
                                <circle cx="34" cy="38" r="4" fill="currentColor" />
                                <path d="M6 22h36" stroke="#f4b942" strokeWidth="2" />
                            </svg>
                            <span>UTMS</span>
                        </div>
                        <h1>Система управління міським транспортом</h1>
                        <p className="auth-brand-tagline">
                            Маршрути, розклад, моніторинг руху та AI-асистент — все в одному місці.
                        </p>
                        <ul className="auth-features">
                            <li>
                                <span className="auth-feature-icon">🗺️</span>
                                Перегляд маршрутів і розкладу
                            </li>
                            <li>
                                <span className="auth-feature-icon">🔍</span>
                                Пошук рейсів між зупинками
                            </li>
                            <li>
                                <span className="auth-feature-icon">🤖</span>
                                Розумний помічник для операторів
                            </li>
                        </ul>
                    </div>
                    <div className="auth-brand-routes" aria-hidden="true">
                        <div className="route-line route-line--1" />
                        <div className="route-line route-line--2" />
                        <div className="route-line route-line--3" />
                    </div>
                </aside>

                <section className="auth-panel">
                    <div className="auth-card">
                        <div className="auth-tabs">
                            <button
                                type="button"
                                className={authMode === "login" ? "auth-tab active" : "auth-tab"}
                                onClick={() => { setAuthMode("login"); setAuthError(""); }}
                            >
                                Вхід
                            </button>
                            <button
                                type="button"
                                className={authMode === "register" ? "auth-tab active" : "auth-tab"}
                                onClick={() => { setAuthMode("register"); setAuthError(""); }}
                            >
                                Реєстрація
                            </button>
                        </div>

                        {authMode === "login" ? (
                            <>
                                <h2>Ласкаво просимо</h2>
                                <p className="auth-subtitle">Увійдіть, щоб керувати транспортною мережею</p>
                                <form onSubmit={handleLogin} className="auth-form">
                                    <label className="auth-field">
                                        <span>Email</span>
                                        <input name="email" type="email" placeholder="you@city.gov.ua" required disabled={authLoading} />
                                    </label>
                                    <label className="auth-field">
                                        <span>Пароль</span>
                                        <input name="password" type="password" placeholder="••••••••" required disabled={authLoading} />
                                    </label>
                                    {authError && <p className="auth-error">{authError}</p>}
                                    <button type="submit" className="auth-submit" disabled={authLoading}>
                                        {authLoading ? "Вхід..." : "Увійти в систему"}
                                    </button>
                                </form>
                            </>
                        ) : (
                            <>
                                <h2>Створити акаунт</h2>
                                <p className="auth-subtitle">Приєднуйтесь до команди управління транспортом</p>
                                <form onSubmit={handleRegister} className="auth-form">
                                    <label className="auth-field">
                                        <span>Ім'я користувача</span>
                                        <input name="username" placeholder="operator_01" required disabled={authLoading} />
                                    </label>
                                    <label className="auth-field">
                                        <span>Email</span>
                                        <input name="email" type="email" placeholder="you@city.gov.ua" required disabled={authLoading} />
                                    </label>
                                    <label className="auth-field">
                                        <span>Пароль</span>
                                        <input name="password" type="password" placeholder="••••••••" required disabled={authLoading} />
                                    </label>
                                    {authError && <p className="auth-error">{authError}</p>}
                                    <button type="submit" className="auth-submit" disabled={authLoading}>
                                        {authLoading ? "Реєстрація..." : "Зареєструватися"}
                                    </button>
                                </form>
                            </>
                        )}
                    </div>
                </section>
            </div>
        );
    }

    return <MainApp token={token} onLogout={handleLogout} />;
}

function MainApp({ token, onLogout }) {
    const [tab, setTab] = useState("routes");
    const [mapCoords, setMapCoords] = useState(null);
    const [currentUser, setCurrentUser] = useState(null);
    const [toastItems, setToastItems] = useState([]);
    const [lastChatEvent, setLastChatEvent] = useState(null);
    const [wsState, setWsState] = useState("disconnected"); // disconnected | connected
    const toastChannelRef = useRef(null);

    const dismissToast = useCallback((id) => {
        setToastItems((prev) => prev.filter((t) => t.id !== id));
        toastChannelRef.current?.postMessage({ type: "dismiss", id });
    }, []);

    const addChatToast = useCallback((payload) => {
        const id = getChatToastId(payload);
        setToastItems((prev) => {
            if (prev.some((t) => t.id === id)) return prev;
            return [
                {
                    id,
                    title: "Нове повідомлення",
                    subtitle: `${payload.sender_role ?? "unknown"} #${payload.sender_id ?? "—"}`,
                    text: payload.text ?? "",
                },
                ...prev,
            ].slice(0, 4);
        });
    }, []);

    useEffect(() => {
        if (typeof BroadcastChannel === "undefined") return undefined;

        const channel = new BroadcastChannel(CHAT_TOAST_CHANNEL);
        toastChannelRef.current = channel;

        channel.onmessage = (event) => {
            if (event.data?.type === "dismiss" && event.data.id) {
                setToastItems((prev) => prev.filter((t) => t.id !== event.data.id));
            }
        };

        return () => {
            channel.close();
            toastChannelRef.current = null;
        };
    }, []);

    const navItems = [
        { id: "routes", label: "Всі маршрути" },
        { id: "route-number", label: "Маршрут за номером" },
        { id: "search", label: "Пошук між зупинками" },
        { id: "vehicle-state", label: "Стан транспорту" },
        { id: "chats", label: "Чати" },
    ];

    const isAdmin = currentUser?.role === "admin";

    useEffect(() => {
        const fetchMe = async () => {
            try {
                const res = await fetch(`${API_BASE}/me`, {
                    headers: { Authorization: `Bearer ${token}` },
                });

                if (res.status === 401) {
                    onLogout();
                    return;
                }

                if (res.ok) {
                    setCurrentUser(await res.json());
                }
            } catch (err) {
                console.error(err);
            }
        };

        fetchMe();
    }, [token, onLogout]);

    useEffect(() => {
        if (!token) return;

        const wsUrl =
            API_BASE.replace(/^http:/, "ws:").replace(/^https:/, "wss:") +
            `/ws/connect?token=${encodeURIComponent(token)}`;
        const ws = new WebSocket(wsUrl);
        setWsState("disconnected");

        ws.onmessage = (evt) => {
            try {
                const payload = JSON.parse(evt.data);
                if (payload?.type === "connected") {
                    setWsState("connected");
                    return;
                }
                if (payload?.type === "chat.message") {
                    setLastChatEvent(payload);
                    addChatToast(payload);
                }
            } catch {
                // ignore malformed events
            }
        };

        ws.onclose = (evt) => {
            setWsState("disconnected");
            // 4401 = invalid/missing token (backend behavior)
            if (evt?.code === 4401) {
                onLogout();
            }
        };

        return () => {
            ws.close();
        };
    }, [token, onLogout, addChatToast]);

    useEffect(() => {
        if (tab === "admin" && currentUser && !isAdmin) {
            setTab("routes");
        }
    }, [tab, currentUser, isAdmin]);

    return (
        <div className="app">
            <aside className="sidebar">
                <div className="sidebar-brand">
                    <svg viewBox="0 0 48 48" width="32" height="32" aria-hidden="true">
                        <rect x="6" y="14" width="36" height="22" rx="4" fill="#f4b942" opacity="0.95" />
                        <rect x="10" y="18" width="10" height="8" rx="1.5" fill="#0d2137" />
                        <rect x="28" y="18" width="10" height="8" rx="1.5" fill="#0d2137" />
                        <circle cx="14" cy="38" r="4" fill="#f4b942" />
                        <circle cx="34" cy="38" r="4" fill="#f4b942" />
                    </svg>
                    <span>UTMS</span>
                </div>

                <nav className="sidebar-nav">
                    {navItems.map((item) => (
                        <button
                            key={item.id}
                            type="button"
                            className={tab === item.id ? "sidebar-link active" : "sidebar-link"}
                            onClick={() => setTab(item.id)}
                        >
                            {item.label}
                        </button>
                    ))}
                </nav>

                <div className="sidebar-spacer" />

                {isAdmin && (
                    <>
                        <div className="sidebar-gap" />
                        <nav className="sidebar-nav sidebar-nav--admin">
                            <button
                                type="button"
                                className={tab === "admin" ? "sidebar-link active" : "sidebar-link"}
                                onClick={() => setTab("admin")}
                            >
                                For admin
                            </button>
                        </nav>
                    </>
                )}

                <button type="button" className="sidebar-logout" onClick={onLogout}>
                    Вийти
                </button>
            </aside>
            <main>
                {tab === "routes" && <RoutesPage token={token} onLogout={onLogout} />}
                {tab === "route-number" && <RouteByNumberPage token={token} onLogout={onLogout} />}
                {tab === "search" && <SearchRoute token={token} />}
                {tab === "vehicle-state" && <VehicleStatePage token={token} onLogout={onLogout} />}
                {tab === "chats" && (
                    <ChatsPage
                        token={token}
                        currentUser={currentUser}
                        onLogout={onLogout}
                        lastChatEvent={lastChatEvent}
                        wsState={wsState}
                    />
                )}
                {tab === "admin" && isAdmin && <AdminPage token={token} onLogout={onLogout} />}
                {tab === "map" && <MapView coords={mapCoords} />}
            </main>
            <AiChat token={token} onLogout={onLogout} />

            {toastItems.length > 0 && (
                <div className="toast-stack" role="status" aria-live="polite">
                    {toastItems.map((t) => (
                        <div key={t.id} className="toast">
                            <button
                                type="button"
                                className="toast-close"
                                onClick={() => dismissToast(t.id)}
                                aria-label="Закрити"
                            >
                                ×
                            </button>
                            <button
                                type="button"
                                className="toast-body"
                                onClick={() => setTab("chats")}
                                title="Відкрити чати"
                            >
                                <div className="toast-title">{t.title}</div>
                                {t.subtitle && <div className="toast-subtitle">{t.subtitle}</div>}
                                <div className="toast-text">{t.text}</div>
                            </button>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
}

function ChatsPage({ token, currentUser, onLogout, lastChatEvent, wsState }) {
    const [conversations, setConversations] = useState([]);
    const [selectedOtherId, setSelectedOtherId] = useState(null);
    const [activeConversation, setActiveConversation] = useState(null);
    const [messageText, setMessageText] = useState("");
    const [loadingList, setLoadingList] = useState(false);
    const [loadingThread, setLoadingThread] = useState(false);
    const [sending, setSending] = useState(false);
    const [error, setError] = useState("");

    const isAdmin = currentUser?.role === "admin";

    const getOtherIdFromConversation = (c) => {
        if (!c) return null;
        if (isAdmin) return c.user_id ?? c.other_id ?? c.recipient_id ?? null;
        return c.admin_id ?? c.other_id ?? c.sender_id ?? null;
    };

    const getLatestMessage = (c) => {
        const msgs = Array.isArray(c?.messages) ? c.messages : [];
        return msgs.length > 0 ? msgs[msgs.length - 1] : null;
    };

    const loadMyConversations = async () => {
        setLoadingList(true);
        setError("");
        try {
            const res = await fetch(`${API_BASE}/chat/my`, {
                headers: { Authorization: `Bearer ${token}` },
            });

            if (res.status === 401) {
                onLogout();
                return;
            }

            const data = await res.json().catch(() => []);
            if (!res.ok) {
                setError(data.detail || "Не вдалося завантажити чати");
                setConversations([]);
                return;
            }

            setConversations(Array.isArray(data) ? data : []);
        } catch (err) {
            console.error(err);
            setError("Помилка з'єднання");
            setConversations([]);
        } finally {
            setLoadingList(false);
        }
    };

    const loadConversation = async (otherId) => {
        if (!otherId) return;
        setLoadingThread(true);
        setError("");
        try {
            const res = await fetch(`${API_BASE}/chat/conversations/${otherId}`, {
                headers: { Authorization: `Bearer ${token}` },
            });

            if (res.status === 401) {
                onLogout();
                return;
            }

            const data = await res.json().catch(() => ({}));
            if (!res.ok) {
                setError(data.detail || "Не вдалося відкрити діалог");
                setActiveConversation(null);
                return;
            }

            setActiveConversation(data);
        } catch (err) {
            console.error(err);
            setError("Помилка з'єднання");
            setActiveConversation(null);
        } finally {
            setLoadingThread(false);
        }
    };

    useEffect(() => {
        loadMyConversations();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        if (selectedOtherId != null) {
            loadConversation(selectedOtherId);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [selectedOtherId]);

    useEffect(() => {
        const payload = lastChatEvent;
        if (!payload || payload.type !== "chat.message") return;

        // If we are currently viewing the thread with the sender, append instantly.
        // (For driver/user: sender is admin_id. For admin: sender can be driver/user in future.)
        if (selectedOtherId != null && payload.sender_id === selectedOtherId) {
            setActiveConversation((prev) => {
                if (!prev) return prev;
                const prevMessages = Array.isArray(prev.messages) ? prev.messages : [];
                return {
                    ...prev,
                    messages: [
                        ...prevMessages,
                        {
                            text: payload.text,
                            sender_id: payload.sender_id,
                            sender_role: payload.sender_role,
                            sent_at: payload.sent_at,
                        },
                    ],
                };
            });
        }

        // Update inbox preview list (best-effort). If unknown thread, reload list.
        setConversations((prev) => {
            let found = false;
            const updated = prev.map((c) => {
                const otherId = getOtherIdFromConversation(c);
                if (otherId == null) return c;

                // For recipient (driver/user), otherId == admin_id which equals payload.sender_id.
                // For future driver->admin messages, this still works as preview based on sender.
                if (otherId !== payload.sender_id) return c;

                found = true;
                const msgs = Array.isArray(c.messages) ? c.messages : [];
                return {
                    ...c,
                    messages: [
                        ...msgs,
                        {
                            text: payload.text,
                            sender_id: payload.sender_id,
                            sender_role: payload.sender_role,
                            sent_at: payload.sent_at,
                        },
                    ],
                };
            });

            if (!found) {
                // don't block UI; just refresh inbox
                loadMyConversations();
            }

            return updated;
        });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [lastChatEvent]);

    const handleSend = async (e) => {
        e.preventDefault();
        if (!messageText.trim() || selectedOtherId == null) return;

        setSending(true);
        setError("");
        try {
            const res = await fetch(`${API_BASE}/chat/messages`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify({ user_id: selectedOtherId, text: messageText.trim() }),
            });

            if (res.status === 401) {
                onLogout();
                return;
            }

            const data = await res.json().catch(() => ({}));
            if (!res.ok) {
                setError(data.detail || "Не вдалося відправити повідомлення");
                return;
            }

            setMessageText("");
            setActiveConversation(data);
            loadMyConversations();
        } catch (err) {
            console.error(err);
            setError("Помилка з'єднання");
        } finally {
            setSending(false);
        }
    };

    return (
        <div className="chats-page">
            <div className="page-header">
                <h1>Чати</h1>
                <p>Перегляд діалогів і історії повідомлень</p>
            </div>

            {error && <p className="form-error content-card">{error}</p>}

            <div className="chat-layout">
                <aside className="chat-inbox content-card">
                    <div className="chat-inbox-header">
                        <h3>Діалоги</h3>
                        <span className="chat-ws-state" title="WebSocket статус">
                            WS: {wsState === "connected" ? "on" : "off"}
                        </span>
                        <button type="button" className="btn-outline" onClick={loadMyConversations} disabled={loadingList}>
                            {loadingList ? "..." : "Оновити"}
                        </button>
                    </div>

                    {conversations.length === 0 ? (
                        <p className="empty-hint">
                            {isAdmin
                                ? "Поки що немає діалогів. Відкрийте водія на вкладці For admin і надішліть повідомлення."
                                : "Поки що немає діалогів."}
                        </p>
                    ) : (
                        <div className="chat-inbox-list">
                            {conversations.map((c) => {
                                const otherId = getOtherIdFromConversation(c);
                                const latest = getLatestMessage(c);
                                const latestText = latest?.text ?? "";
                                const otherName = c.other_username ?? c.admin_username ?? c.user_username ?? null;
                                const title = otherName ? otherName : `ID ${otherId}`;

                                return (
                                    <button
                                        key={c.id ?? `${otherId}-${latest?.sent_at ?? ""}`}
                                        type="button"
                                        className={selectedOtherId === otherId ? "chat-inbox-item active" : "chat-inbox-item"}
                                        onClick={() => setSelectedOtherId(otherId)}
                                    >
                                        <div className="chat-inbox-title">{title}</div>
                                        <div className="chat-inbox-preview">{latestText || "—"}</div>
                                    </button>
                                );
                            })}
                        </div>
                    )}
                </aside>

                <section className="chat-thread content-card">
                    {selectedOtherId == null ? (
                        <p className="empty-hint">Оберіть діалог зліва, щоб переглянути історію</p>
                    ) : (
                        <>
                            <div className="chat-thread-header">
                                <h3>Діалог з {`ID ${selectedOtherId}`}</h3>
                                {loadingThread && <span className="chat-thread-loading">Завантаження...</span>}
                            </div>

                            <div className="chat-thread-messages">
                                {(activeConversation?.messages?.length ?? 0) === 0 ? (
                                    <p className="empty-hint">Повідомлень ще немає</p>
                                ) : (
                                    activeConversation.messages.map((m, idx) => {
                                        const isMe = currentUser?.id != null && m.sender_id === currentUser.id;
                                        return (
                                            <div
                                                key={m.id ?? `${m.sent_at ?? idx}-${idx}`}
                                                className={isMe ? "chat-thread-bubble me" : "chat-thread-bubble other"}
                                            >
                                                {m.text}
                                            </div>
                                        );
                                    })
                                )}
                            </div>

                            {isAdmin && (
                                <form className="chat-thread-compose" onSubmit={handleSend}>
                                    <input
                                        value={messageText}
                                        onChange={(e) => setMessageText(e.target.value)}
                                        placeholder="Напишіть повідомлення..."
                                        disabled={sending}
                                    />
                                    <button type="submit" className="btn-primary" disabled={sending || !messageText.trim()}>
                                        {sending ? "..." : "Надіслати"}
                                    </button>
                                </form>
                            )}

                            {!isAdmin && (
                                <p className="empty-hint chat-thread-note">
                                    У цій версії чат дозволяє відповідати лише адміністраторам.
                                </p>
                            )}
                        </>
                    )}
                </section>
            </div>
        </div>
    );
}

function AdminPage({ token, onLogout }) {
    const tabs = [
        { id: "admin", label: "Admins", role: "admin" },
        { id: "user", label: "Users", role: "user" },
        { id: "driver", label: "Drivers", role: "driver" },
    ];

    const [activeTab, setActiveTab] = useState("driver");
    const [q, setQ] = useState("");
    const [page, setPage] = useState(1);
    const [size, setSize] = useState(20);
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");
    const [composeOpen, setComposeOpen] = useState(false);
    const [composeUser, setComposeUser] = useState(null);
    const [composeText, setComposeText] = useState("");
    const [sending, setSending] = useState(false);

    const role = tabs.find((t) => t.id === activeTab)?.role ?? "driver";

    const fetchUsers = async ({ nextPage = page, nextSize = size, nextQ = q } = {}) => {
        setLoading(true);
        setError("");

        try {
            const params = new URLSearchParams({
                role,
                page: String(nextPage),
                size: String(nextSize),
            });
            if (nextQ.trim()) params.set("q", nextQ.trim());

            const res = await fetch(`${API_BASE}/users?${params.toString()}`, {
                headers: { Authorization: `Bearer ${token}` },
            });

            if (res.status === 401) {
                onLogout();
                return;
            }

            const json = await res.json().catch(() => ({}));
            if (!res.ok) {
                setError(json.detail || "Не вдалося завантажити користувачів");
                setData(null);
                return;
            }

            setData(json);
        } catch (err) {
            console.error(err);
            setError("Помилка з'єднання");
            setData(null);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        setPage(1);
        fetchUsers({ nextPage: 1 });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [activeTab]);

    useEffect(() => {
        fetchUsers();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [page, size]);

    const handleSubmitSearch = (e) => {
        e.preventDefault();
        setPage(1);
        fetchUsers({ nextPage: 1 });
    };

    const items = Array.isArray(data?.items) ? data.items : [];
    const pages = data?.pages ?? 1;
    const total = data?.total ?? 0;

    const closeCompose = () => {
        setComposeOpen(false);
        setComposeUser(null);
        setComposeText("");
        setSending(false);
    };

    const openCompose = (user) => {
        setComposeUser(user);
        setComposeText("");
        setComposeOpen(true);
    };

    const sendMessage = async () => {
        const text = composeText.trim();
        if (!composeUser?.id || !text) return;

        setSending(true);
        setError("");
        try {
            const res = await fetch(`${API_BASE}/chat/messages`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify({ user_id: composeUser.id, text }),
            });

            if (res.status === 401) {
                onLogout();
                return;
            }

            const json = await res.json().catch(() => ({}));
            if (!res.ok) {
                setError(json.detail || "Не вдалося відправити повідомлення");
                return;
            }

            closeCompose();
        } catch (err) {
            console.error(err);
            setError("Помилка з'єднання");
        } finally {
            setSending(false);
        }
    };

    return (
        <div className="admin-page">
            <div className="page-header">
                <h1>Адміністрування</h1>
                <p>Користувачі системи з фільтром за роллю, пошуком та пагінацією</p>
            </div>

            <div className="content-card admin-tabs">
                <div className="admin-tab-buttons">
                    {tabs.map((t) => (
                        <button
                            key={t.id}
                            type="button"
                            className={activeTab === t.id ? "admin-tab active" : "admin-tab"}
                            onClick={() => setActiveTab(t.id)}
                        >
                            {t.label}
                        </button>
                    ))}
                </div>

                <form className="admin-toolbar" onSubmit={handleSubmitSearch}>
                    <label className="form-field admin-search">
                        <span>Пошук (q)</span>
                        <input
                            value={q}
                            onChange={(e) => setQ(e.target.value)}
                            placeholder="email / username / тощо"
                            disabled={loading}
                        />
                    </label>

                    <label className="form-field admin-size">
                        <span>Розмір сторінки</span>
                        <select
                            value={size}
                            onChange={(e) => {
                                setPage(1);
                                setSize(Number(e.target.value));
                            }}
                            disabled={loading}
                        >
                            {[10, 20, 50, 100].map((n) => (
                                <option key={n} value={n}>
                                    {n}
                                </option>
                            ))}
                        </select>
                    </label>

                    <button type="submit" className="btn-primary" disabled={loading}>
                        {loading ? "Пошук..." : "Застосувати"}
                    </button>
                </form>
            </div>

            {error && <p className="form-error content-card">{error}</p>}

            <div className="content-card admin-table-card">
                <div className="admin-table-header">
                    <h3>Список користувачів</h3>
                    <span className="admin-table-meta">
                        Всього: {total} · Сторінка: {page} / {pages}
                    </span>
                </div>

                <div className="admin-table-wrap">
                    <table className="admin-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Повідомлення</th>
                            </tr>
                        </thead>
                        <tbody>
                            {items.length === 0 ? (
                                <tr>
                                    <td colSpan={5} className="admin-empty">
                                        {loading ? "Завантаження..." : "Немає даних"}
                                    </td>
                                </tr>
                            ) : (
                                items.map((u) => (
                                    <tr key={u.id}>
                                        <td>{u.id}</td>
                                        <td>{u.username}</td>
                                        <td>{u.email}</td>
                                        <td>
                                            <span className={`admin-role admin-role--${u.role}`}>{u.role}</span>
                                        </td>
                                        <td>
                                            <button
                                                type="button"
                                                className="btn-outline admin-compose-btn"
                                                onClick={() => openCompose(u)}
                                            >
                                                Написати
                                            </button>
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>

                <div className="admin-pagination">
                    <button
                        type="button"
                        className="btn-secondary"
                        onClick={() => setPage((p) => Math.max(1, p - 1))}
                        disabled={loading || page <= 1}
                    >
                        Назад
                    </button>
                    <button
                        type="button"
                        className="btn-secondary"
                        onClick={() => setPage((p) => Math.min(pages, p + 1))}
                        disabled={loading || page >= pages}
                    >
                        Вперед
                    </button>
                </div>
            </div>

            {composeOpen && composeUser && (
                <div className="modal-overlay" role="dialog" aria-modal="true">
                    <div className="modal">
                        <div className="modal-header">
                            <h3>Повідомлення користувачу</h3>
                            <button type="button" className="modal-close" onClick={closeCompose} aria-label="Закрити">
                                ×
                            </button>
                        </div>
                        <p className="modal-subtitle">
                            Кому: <strong>{composeUser.username}</strong> ({composeUser.email}) · роль:{" "}
                            <span className={`admin-role admin-role--${composeUser.role}`}>{composeUser.role}</span>
                        </p>

                        <label className="form-field">
                            <span>Текст повідомлення</span>
                            <textarea
                                value={composeText}
                                onChange={(e) => setComposeText(e.target.value)}
                                placeholder="Напишіть повідомлення..."
                                rows={8}
                                disabled={sending}
                            />
                        </label>

                        <div className="modal-actions">
                            <button type="button" className="btn-secondary" onClick={closeCompose} disabled={sending}>
                                Скасувати
                            </button>
                            <button
                                type="button"
                                className="btn-primary"
                                onClick={sendMessage}
                                disabled={sending || !composeText.trim()}
                            >
                                {sending ? "Надсилання..." : "Надіслати"}
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}

function ChatMarkdown({ content }) {
    return (
        <div className="chat-markdown">
            <ReactMarkdown
                remarkPlugins={[remarkGfm]}
                components={{
                    table: ({ node, ...props }) => (
                        <div className="table-wrap">
                            <table {...props} />
                        </div>
                    ),
                }}
            >
                {content}
            </ReactMarkdown>
        </div>
    );
}

function AiChat({ token, onLogout }) {
    const [open, setOpen] = useState(false);
    const [messages, setMessages] = useState([]);
    const [input, setInput] = useState("");
    const [streaming, setStreaming] = useState(false);
    const messagesEndRef = useRef(null);

    useEffect(() => {
        if (open) {
            messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
        }
    }, [messages, open]);

    const appendAssistantChunk = (chunk) => {
        setMessages((prev) => {
            const updated = [...prev];
            const last = updated[updated.length - 1];
            if (last?.role !== "assistant") return prev;
            updated[updated.length - 1] = { ...last, content: last.content + chunk };
            return updated;
        });
    };

    const handleSend = async (e) => {
        e.preventDefault();
        const text = input.trim();
        if (!text || streaming) return;

        setInput("");
        setMessages((prev) => [...prev, { role: "user", content: text }, { role: "assistant", content: "" }]);
        setStreaming(true);

        try {
            const res = await fetch(`${API_BASE}/ai/run/stream`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify({ message: text }),
            });

            if (res.status === 401) {
                onLogout();
                return;
            }

            if (!res.ok) {
                const err = await res.json().catch(() => ({}));
                appendAssistantChunk(err.detail || "Помилка відповіді сервера");
                return;
            }

            const reader = res.body.getReader();
            const decoder = new TextDecoder();
            let buffer = "";

            while (true) {
                const { done, value } = await reader.read();
                if (done) break;

                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split("\n");
                buffer = lines.pop() || "";

                for (const line of lines) {
                    if (!line.startsWith("data: ")) continue;
                    try {
                        const data = JSON.parse(line.slice(6));
                        if (data.content) appendAssistantChunk(data.content);
                        if (data.error) appendAssistantChunk(`\n\nПомилка: ${data.error}`);
                    } catch {
                        // ignore malformed SSE lines
                    }
                }
            }
        } catch (err) {
            console.error(err);
            appendAssistantChunk("\n\nПомилка з'єднання");
        } finally {
            setStreaming(false);
        }
    };

    return (
        <>
            <button
                type="button"
                className="chat-fab"
                onClick={() => setOpen((v) => !v)}
                aria-label="AI асистент"
                title="AI асистент"
            >
                <svg viewBox="0 0 24 24" width="28" height="28" fill="currentColor" aria-hidden="true">
                    <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H5.17L4 17.17V4h16v12z" />
                    <path d="M7 9h10v2H7zm0-3h10v2H7zm0 6h7v2H7z" />
                </svg>
            </button>

            {open && (
                <div className="chat-panel">
                    <div className="chat-header">
                        <h3>AI асистент</h3>
                        <button type="button" className="chat-close" onClick={() => setOpen(false)} aria-label="Закрити">
                            ×
                        </button>
                    </div>

                    <div className="chat-messages">
                        {messages.length === 0 && (
                            <p className="chat-placeholder">Запитайте про маршрути, розклад або транспорт.</p>
                        )}
                        {messages.map((msg, i) => (
                            <div key={i} className={`chat-message chat-message--${msg.role}`}>
                                {msg.role === "assistant" ? (
                                    msg.content ? (
                                        <ChatMarkdown content={msg.content} />
                                    ) : (
                                        streaming && i === messages.length - 1 ? "…" : ""
                                    )
                                ) : (
                                    msg.content
                                )}
                            </div>
                        ))}
                        <div ref={messagesEndRef} />
                    </div>

                    <form className="chat-input-form" onSubmit={handleSend}>
                        <input
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            placeholder="Напишіть повідомлення..."
                            disabled={streaming}
                        />
                        <button type="submit" disabled={streaming || !input.trim()}>
                            {streaming ? "…" : "→"}
                        </button>
                    </form>
                </div>
            )}
        </>
    );
}

function RouteByNumberPage({ token, onLogout }) {
    const [routeNumber, setRouteNumber] = useState("");
    const [schedulesLimit, setSchedulesLimit] = useState(4);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");
    const [route, setRoute] = useState(null);

    const handleSearch = async (e) => {
        e.preventDefault();
        const number = routeNumber.trim();
        if (!number) return setError("Введіть номер маршруту");

        setLoading(true);
        setError("");
        setRoute(null);

        try {
            const params = new URLSearchParams({ upcoming_schedules_limit: String(schedulesLimit) });
            const res = await fetch(
                `${API_BASE}/routes/routes/by-number/${encodeURIComponent(number)}?${params}`,
                { headers: { Authorization: `Bearer ${token}` } },
            );

            if (res.status === 401) {
                onLogout();
                return;
            }

            const data = await res.json();
            if (!res.ok) {
                setError(data.detail || "Маршрут не знайдено");
                return;
            }

            setRoute(data);
        } catch (err) {
            console.error(err);
            setError("Помилка з'єднання");
        } finally {
            setLoading(false);
        }
    };

    const getStopLabel = (stop, index) => {
        if (typeof stop === "string") return stop;
        return stop.name ?? stop.stop_name ?? stop.title ?? `Зупинка ${index + 1}`;
    };

    return (
        <div className="route-number-page">
            <div className="page-header">
                <h1>Маршрут за номером</h1>
                <p>Детальна інформація про маршрут, зупинки та найближчі рейси</p>
            </div>

            <form onSubmit={handleSearch} className="route-number-form">
                <label className="route-number-field">
                    <span>Номер маршруту</span>
                    <input
                        value={routeNumber}
                        onChange={(e) => setRouteNumber(e.target.value)}
                        placeholder="Наприклад: 24"
                        disabled={loading}
                    />
                </label>
                <label className="route-number-field route-number-field--small">
                    <span>Кількість рейсів</span>
                    <input
                        type="number"
                        min={1}
                        max={20}
                        value={schedulesLimit}
                        onChange={(e) => setSchedulesLimit(Number(e.target.value))}
                        disabled={loading}
                    />
                </label>
                <button type="submit" className="route-number-submit" disabled={loading || !routeNumber.trim()}>
                    {loading ? "Пошук..." : "Знайти маршрут"}
                </button>
            </form>

            {error && <p className="route-number-error">{error}</p>}

            {route && (
                <div className="route-number-result">
                    <div className="route-number-hero">
                        <div className="route-number-badge">№{route.route_number}</div>
                        <div>
                            <h2>{route.route_name}</h2>
                            <div className="route-number-stats">
                                <span>{route.distance_km} км</span>
                                <span>{route.stops_count} зупинок</span>
                                <span className={route.average_delay_minutes > 0 ? "delay-warn" : ""}>
                                    Затримка: {route.average_delay_minutes} хв
                                </span>
                            </div>
                        </div>
                    </div>

                    {route.stops?.length > 0 && (
                        <section className="route-number-section">
                            <h3>Зупинки маршруту</h3>
                            <ol className="route-stops-list">
                                {route.stops.map((stop, i) => (
                                    <li key={stop.id ?? i}>
                                        <span className="stop-order">{i + 1}</span>
                                        <span>{getStopLabel(stop, i)}</span>
                                    </li>
                                ))}
                            </ol>
                        </section>
                    )}

                    {route.upcoming_schedules?.length > 0 ? (
                        <section className="route-number-section">
                            <h3>Найближчі рейси</h3>
                            <div className="schedule-cards">
                                {route.upcoming_schedules.map((s) => (
                                    <div key={s.schedule_id} className="schedule-card">
                                        <div className="schedule-times">
                                            <span className="schedule-dep">{s.departure_time}</span>
                                            <span className="schedule-arrow">→</span>
                                            <span className="schedule-arr">{s.arrival_time}</span>
                                        </div>
                                        {s.actual_arrival_time && (
                                            <p className="schedule-actual">Фактичне прибуття: {s.actual_arrival_time}</p>
                                        )}
                                        {s.delay_minutes != null && s.delay_minutes > 0 && (
                                            <span className="schedule-delay">+{s.delay_minutes} хв</span>
                                        )}
                                        {s.vehicle && (
                                            <div className="schedule-vehicle">
                                                <strong>{s.vehicle.brand} {s.vehicle.model}</strong>
                                                <span>{s.vehicle.type} · {s.vehicle.registration_number}</span>
                                                <span>Вмістимість: {s.vehicle.capacity} осіб</span>
                                            </div>
                                        )}
                                    </div>
                                ))}
                            </div>
                        </section>
                    ) : (
                        <p className="route-number-empty">Найближчі рейси відсутні</p>
                    )}
                </div>
            )}
        </div>
    );
}

function VehicleStatePage({ token, onLogout }) {
    const [prompt, setPrompt] = useState("");
    const [loadingModel, setLoadingModel] = useState(false);
    const [running, setRunning] = useState(false);
    const [modelStatus, setModelStatus] = useState(null);
    const [result, setResult] = useState(null);

    const handleLoadModel = async () => {
        setLoadingModel(true);
        try {
            const res = await fetch(`${API_BASE}/ai/finetuned/load`, {
                method: "POST",
                headers: { Authorization: `Bearer ${token}` },
            });

            if (res.status === 401) {
                onLogout();
                return;
            }

            const data = await res.json();
            if (!res.ok) {
                alert(data.detail || "Не вдалося завантажити модель");
                return;
            }

            setModelStatus(data);
            alert("Модель успішно завантажена");
        } catch (err) {
            console.error(err);
            alert("Помилка з'єднання");
        } finally {
            setLoadingModel(false);
        }
    };

    const handleRun = async (e) => {
        e.preventDefault();
        if (!prompt.trim()) return alert("Введіть опис стану транспорту");

        setRunning(true);
        setResult(null);
        try {
            const res = await fetch(`${API_BASE}/ai/finetuned/run`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`,
                },
                body: JSON.stringify({ prompt: prompt.trim() }),
            });

            if (res.status === 401) {
                onLogout();
                return;
            }

            const data = await res.json();
            if (!res.ok) {
                alert(data.detail || "Помилка обробки запиту");
                return;
            }

            setResult(data);
        } catch (err) {
            console.error(err);
            alert("Помилка з'єднання");
        } finally {
            setRunning(false);
        }
    };

    return (
        <div className="vehicle-state-page">
            <div className="page-header">
                <h1>Стан транспорту</h1>
                <p>Fine-tuned модель для аналізу стану транспортного засобу</p>
            </div>

            <div className="content-card vehicle-state-load-card">
                <h3>Завантаження моделі</h3>
                <p className="card-desc">Перед аналізом потрібно один раз завантажити модель у пам'ять сервера.</p>
                <div className="vehicle-state-actions">
                    <button
                        type="button"
                        onClick={handleLoadModel}
                        disabled={loadingModel}
                        className="btn-secondary"
                    >
                        {loadingModel ? "Завантаження..." : "Завантажити модель"}
                    </button>
                    {modelStatus && (
                        <span className="vehicle-state-status">
                            {modelStatus.loaded !== false ? "Модель завантажена" : "Модель не завантажена"}
                        </span>
                    )}
                </div>
            </div>

            <form onSubmit={handleRun} className="content-card vehicle-state-form">
                <label className="form-field" htmlFor="vehicle-prompt">
                    <span>Опис ситуації</span>
                    <textarea
                        id="vehicle-prompt"
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        placeholder="Опишіть стан транспорту, симптоми, пробіг, умови експлуатації..."
                        rows={8}
                        disabled={running}
                    />
                </label>
                <button type="submit" className="btn-primary" disabled={running || !prompt.trim()}>
                    {running ? "Обробка..." : "Аналізувати"}
                </button>
            </form>

            {result && (
                <div className="content-card vehicle-state-result">
                    <h3>Результат аналізу</h3>
                    {result.model && (
                        <p className="vehicle-state-meta">
                            Модель: {result.model}
                            {result.base_model && ` · базова: ${result.base_model}`}
                        </p>
                    )}
                    <pre>{result.response}</pre>
                </div>
            )}
        </div>
    );
}

function MapFitBounds({ positions }) {
    const map = useMap();

    useEffect(() => {
        if (positions.length > 0) {
            map.fitBounds(positions, { padding: [48, 48] });
        }
    }, [map, positions]);

    return null;
}

function RoutesMap({ token, onLogout }) {
    const [routes, setRoutes] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    useEffect(() => {
        const fetchMapRoutes = async () => {
            setLoading(true);
            setError("");
            try {
                const res = await fetch(`${API_BASE}/routes/for-map`, {
                    headers: { Authorization: `Bearer ${token}` },
                });

                if (res.status === 401) {
                    onLogout();
                    return;
                }

                const data = await res.json();
                if (!res.ok) {
                    setError(data.detail || "Не вдалося завантажити маршрути для карти");
                    return;
                }

                setRoutes(Array.isArray(data) ? data.slice(0, 5) : []);
            } catch (err) {
                console.error(err);
                setError("Помилка з'єднання");
            } finally {
                setLoading(false);
            }
        };

        fetchMapRoutes();
    }, [token, onLogout]);

    const allPositions = useMemo(
        () =>
            routes.flatMap((route) =>
                [...route.stops]
                    .sort((a, b) => a.order - b.order)
                    .map((s) => [s.latitude, s.longitude]),
            ),
        [routes],
    );

    if (loading) return <p className="empty-hint content-card">Завантаження карти...</p>;
    if (error) return <p className="form-error content-card">{error}</p>;
    if (routes.length === 0) return <p className="empty-hint content-card">Немає маршрутів для відображення</p>;

    return (
        <div className="routes-map-section content-card">
            <div className="routes-map-header">
                <h3>Карта маршрутів</h3>
                <div className="routes-map-legend">
                    {routes.map((route, i) => (
                        <span key={route.id} className="legend-item">
                            <span className="legend-color" style={{ background: ROUTE_MAP_COLORS[i] }} />
                            №{route.route_number} — {route.name}
                        </span>
                    ))}
                </div>
            </div>
            <MapContainer center={DEFAULT_MAP_CENTER} zoom={13} className="routes-map" scrollWheelZoom>
                <TileLayer
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                />
                <MapFitBounds positions={allPositions} />
                {routes.map((route, routeIndex) => {
                    const color = ROUTE_MAP_COLORS[routeIndex];
                    const sortedStops = [...route.stops].sort((a, b) => a.order - b.order);
                    const positions = sortedStops.map((s) => [s.latitude, s.longitude]);

                    return (
                        <Fragment key={route.id}>
                            <Polyline positions={positions} pathOptions={{ color, weight: 4, opacity: 0.85 }} />
                            {sortedStops.map((stop) => (
                                <CircleMarker
                                    key={`${route.id}-${stop.order}-${stop.id}`}
                                    center={[stop.latitude, stop.longitude]}
                                    radius={7}
                                    pathOptions={{ color, fillColor: color, fillOpacity: 1, weight: 2 }}
                                >
                                    <Popup>
                                        <strong>#{stop.order} {stop.name}</strong>
                                        <br />
                                        Маршрут №{route.route_number} — {route.name}
                                    </Popup>
                                </CircleMarker>
                            ))}
                        </Fragment>
                    );
                })}
            </MapContainer>
        </div>
    );
}

function RoutesPage({ token, onLogout }) {
    const [routes, setRoutes] = useState([]);
    const [page, setPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [selectedRoute, setSelectedRoute] = useState(null);
    const [loadingDetails, setLoadingDetails] = useState(false);
    const [showMap, setShowMap] = useState(false);

    useEffect(() => {
        if (selectedRoute) return;

        const fetchRoutes = async () => {
            try {
                const res = await fetch(`${API_BASE}/routes/routes?page=${page}&size=10`, {
                    headers: { Authorization: `Bearer ${token}` },
                });

                if (res.status === 401) {
                    onLogout();
                    return;
                }

                const data = await res.json();
                setRoutes(data.items);
                setTotalPages(data.pages);
            } catch (err) {
                console.error(err);
                alert("Помилка завантаження маршрутів");
            }
        };

        fetchRoutes();
    }, [page, token, selectedRoute, onLogout]);

    const handleSelectRoute = async (routeId) => {
        setLoadingDetails(true);
        try {
            const res = await fetch(`${API_BASE}/routes/routes/${routeId}`, {
                headers: { Authorization: `Bearer ${token}` },
            });

            if (res.status === 401) {
                onLogout();
                return;
            }

            if (!res.ok) {
                alert("Не вдалося завантажити деталі маршруту");
                setLoadingDetails(false);
                return;
            }

            const data = await res.json();
            setSelectedRoute(data);
        } catch (err) {
            console.error(err);
            alert("Помилка завантаження деталей маршруту");
        } finally {
            setLoadingDetails(false);
        }
    };

    const handleBack = () => {
        setSelectedRoute(null);
    };

    if (selectedRoute) {
        return (
            <div className="routes-page">
                <button type="button" className="btn-back" onClick={handleBack}>
                    Назад до списку
                </button>

                <div className="route-number-hero">
                    <div className="route-number-badge">№{selectedRoute.route_number}</div>
                    <div>
                        <h2>{selectedRoute.name}</h2>
                        <div className="route-number-stats">
                            <span>{selectedRoute.distance} км</span>
                            <span className={selectedRoute.average_delay_minutes > 0 ? "delay-warn" : ""}>
                                Середня затримка: {selectedRoute.average_delay_minutes} хв
                            </span>
                        </div>
                    </div>
                </div>

                <section className="content-card">
                    <h3>Розклад</h3>
                    {loadingDetails ? (
                        <p className="empty-hint">Завантаження...</p>
                    ) : selectedRoute.schedules.length > 0 ? (
                        <div className="schedule-cards">
                            {selectedRoute.schedules.map((s) => (
                                <div key={s.id} className="schedule-card">
                                    <div className="schedule-times">
                                        <span className="schedule-dep">{s.departure_time}</span>
                                        <span className="schedule-arrow">→</span>
                                        <span className="schedule-arr">{s.arrival_time}</span>
                                    </div>
                                    {s.vehicle && (
                                        <div className="schedule-vehicle">
                                            <strong>{s.vehicle.brand} {s.vehicle.model}</strong>
                                            <span>{s.vehicle.vehicle_type} · {s.vehicle.registration_number}</span>
                                            <span>Вмістимість: {s.vehicle.capacity} осіб</span>
                                        </div>
                                    )}
                                </div>
                            ))}
                        </div>
                    ) : (
                        <p className="empty-hint">Розклад відсутній</p>
                    )}
                </section>
            </div>
        );
    }

    return (
        <div className="routes-page">
            <div className="page-header">
                <h1>Всі маршрути</h1>
                <p>Перегляд і деталі міських транспортних маршрутів</p>
            </div>

            <div className="routes-page-actions">
                <button
                    type="button"
                    className="btn-primary"
                    onClick={() => setShowMap((v) => !v)}
                >
                    {showMap ? "Приховати карту" : "Показати на карті"}
                </button>
            </div>

            {showMap && <RoutesMap token={token} onLogout={onLogout} />}

            <div className="routes-grid">
                {routes.map((route) => (
                    <button
                        key={route.id}
                        type="button"
                        className="route-card"
                        onClick={() => handleSelectRoute(route.id)}
                    >
                        <span className="route-card-name">{route.name}</span>
                        <span className="route-card-arrow">→</span>
                    </button>
                ))}
            </div>

            {routes.length === 0 && <p className="empty-hint content-card">Маршрутів не знайдено</p>}

            <div className="pagination">
                <button type="button" className="btn-pagination" onClick={() => setPage((p) => Math.max(p - 1, 1))} disabled={page === 1}>
                    Назад
                </button>
                <span className="pagination-info">Сторінка {page} з {totalPages}</span>
                <button type="button" className="btn-pagination" onClick={() => setPage((p) => Math.min(p + 1, totalPages))} disabled={page === totalPages}>
                    Вперед
                </button>
            </div>
        </div>
    );
}

function SearchRouteMapModal({ result, onClose }) {
    const sortedStops = useMemo(
        () => [...(result.stops ?? [])].sort((a, b) => a.order - b.order),
        [result.stops],
    );

    const positions = useMemo(
        () => sortedStops.map((s) => [s.latitude, s.longitude]),
        [sortedStops],
    );

    if (sortedStops.length === 0) {
        return (
            <div className="modal-overlay" role="dialog" aria-modal="true">
                <div className="modal search-route-map-modal">
                    <div className="modal-header">
                        <h3>Маршрут на карті</h3>
                        <button type="button" className="modal-close" onClick={onClose} aria-label="Закрити">
                            ×
                        </button>
                    </div>
                    <p className="empty-hint">Немає координат зупинок для цього маршруту</p>
                </div>
            </div>
        );
    }

    return (
        <div className="modal-overlay" role="dialog" aria-modal="true">
            <div className="modal search-route-map-modal">
                <div className="modal-header">
                    <h3>
                        №{result.route_number} — {result.route_name}
                    </h3>
                    <button type="button" className="modal-close" onClick={onClose} aria-label="Закрити">
                        ×
                    </button>
                </div>
                <p className="modal-subtitle">
                    {result.from_stop} → {result.to_stop}
                    {result.departure_time && result.arrival_time && (
                        <> · {result.departure_time} — {result.arrival_time}</>
                    )}
                </p>

                <MapContainer center={DEFAULT_MAP_CENTER} zoom={13} className="search-route-map" scrollWheelZoom>
                    <TileLayer
                        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    />
                    <MapFitBounds positions={positions} />
                    <Polyline
                        positions={positions}
                        pathOptions={{ color: SEARCH_ROUTE_LINE_COLOR, weight: 4, opacity: 0.9 }}
                    />
                    {sortedStops.map((stop) => (
                        <CircleMarker
                            key={`${stop.order}-${stop.id}`}
                            center={[stop.latitude, stop.longitude]}
                            radius={7}
                            pathOptions={{
                                color: SEARCH_ROUTE_LINE_COLOR,
                                fillColor: SEARCH_ROUTE_LINE_COLOR,
                                fillOpacity: 1,
                                weight: 2,
                            }}
                        >
                            <Popup>
                                <strong>#{stop.order} {stop.name}</strong>
                            </Popup>
                        </CircleMarker>
                    ))}
                </MapContainer>
            </div>
        </div>
    );
}

function SearchRoute({ token }) {
    const [from, setFrom] = useState("");
    const [to, setTo] = useState("");
    const [results, setResults] = useState([]);
    const [loading, setLoading] = useState(false);
    const [searched, setSearched] = useState(false);
    const [error, setError] = useState("");
    const [mapResult, setMapResult] = useState(null);

    const handleSearch = async (e) => {
        e.preventDefault();
        if (!from || !to) return setError("Заповніть обидва поля");

        setLoading(true);
        setError("");
        setSearched(true);

        try {
            const res = await fetch(`${API_BASE}/routes/departures-between-stops/${from}/${to}`, {
                headers: { Authorization: `Bearer ${token}` },
            });

            const data = await res.json();
            if (!Array.isArray(data)) {
                setResults([]);
                setError("Маршрутів не знайдено");
                return;
            }

            setResults(data);
        } catch (err) {
            console.error(err);
            setError("Помилка пошуку маршруту");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="search-page">
            <div className="page-header">
                <h1>Пошук між зупинками</h1>
                <p>Знайдіть рейси від початкової до кінцевої зупинки</p>
            </div>

            <form onSubmit={handleSearch} className="content-card search-form">
                <div className="search-form-row">
                    <label className="form-field">
                        <span>Початкова зупинка</span>
                        <input
                            value={from}
                            onChange={(e) => setFrom(e.target.value)}
                            placeholder="Назва або ID зупинки"
                            disabled={loading}
                        />
                    </label>
                    <label className="form-field">
                        <span>Кінцева зупинка</span>
                        <input
                            value={to}
                            onChange={(e) => setTo(e.target.value)}
                            placeholder="Назва або ID зупинки"
                            disabled={loading}
                        />
                    </label>
                </div>
                {error && <p className="form-error">{error}</p>}
                <button type="submit" className="btn-primary" disabled={loading}>
                    {loading ? "Пошук..." : "Шукати"}
                </button>
            </form>

            {searched && (
                <section className="search-results">
                    <h3>Результати {results.length > 0 && `(${results.length})`}</h3>
                    {results.length === 0 ? (
                        <p className="empty-hint content-card">За вашим запитом нічого не знайдено</p>
                    ) : (
                        <div className="search-results-grid">
                            {results.map((r, i) => (
                                <div key={i} className="search-result-card">
                                    <div className="search-result-route">
                                        <span className="route-number-badge route-number-badge--sm">№{r.route_number}</span>
                                        <span>{r.route_name}</span>
                                    </div>
                                    <div className="search-result-details">
                                        <p><strong>Транспорт:</strong> {r.vehicle_name}</p>
                                        <p><strong>Відправлення:</strong> {r.departure_time ?? r.from_stop_time}</p>
                                        <p><strong>Прибуття:</strong> {r.arrival_time ?? r.to_stop_time}</p>
                                    </div>
                                    <button type="button" className="btn-outline" onClick={() => setMapResult(r)}>
                                        На мапі
                                    </button>
                                </div>
                            ))}
                        </div>
                    )}
                </section>
            )}

            {mapResult && (
                <SearchRouteMapModal result={mapResult} onClose={() => setMapResult(null)} />
            )}
        </div>
    );
}


export default App;
