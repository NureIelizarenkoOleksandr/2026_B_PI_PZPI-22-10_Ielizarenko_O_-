from collections import defaultdict
from datetime import time

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import aliased

from app.api.shemas.routes import DepartureBetweenStopsOut, MapStopOut
from app.db.initial_models import Route, Schedule, Stop, StopTime, Vehicle


def _format_time(value: time | None) -> str | None:
    return value.isoformat() if value else None


async def get_departures_between_stops(
    db: AsyncSession,
    from_stop_name: str,
    to_stop_name: str,
) -> list[DepartureBetweenStopsOut]:
    st1 = aliased(StopTime)
    st2 = aliased(StopTime)

    to_stop_id_subq = (
        select(Stop.id).where(Stop.name == to_stop_name).scalar_subquery()
    )

    stmt = (
        select(Schedule, st1, st2, Route, Vehicle)
        .join(st1, Schedule.stop_times)
        .join(st2, Schedule.stop_times)
        .join(Route, Schedule.route_id == Route.id)
        .join(Vehicle, Schedule.vehicle_id == Vehicle.id)
        .join(Stop, st1.stop_id == Stop.id)
        .where(
            Stop.name == from_stop_name,
            st2.stop_id == to_stop_id_subq,
            st1.stop_order < st2.stop_order,
        )
        .order_by(st1.departure_time)
    )

    result = await db.execute(stmt)
    rows = result.all()
    if not rows:
        return []

    schedule_ids = list({schedule.id for schedule, _, _, _, _ in rows})
    stops_result = await db.execute(
        select(StopTime, Stop)
        .join(Stop, StopTime.stop_id == Stop.id)
        .where(StopTime.schedule_id.in_(schedule_ids))
        .order_by(StopTime.schedule_id, StopTime.stop_order)
    )

    stops_by_schedule: dict[int, list[tuple[StopTime, Stop]]] = defaultdict(list)
    for stop_time, stop in stops_result.all():
        stops_by_schedule[stop_time.schedule_id].append((stop_time, stop))

    departures: list[DepartureBetweenStopsOut] = []
    for schedule, from_stop_time, to_stop_time, route, vehicle in rows:
        segment_stops = [
            MapStopOut(
                order=stop_time.stop_order,
                id=stop.id,
                name=stop.name,
                latitude=stop.latitude,
                longitude=stop.longitude,
            )
            for stop_time, stop in stops_by_schedule.get(schedule.id, [])
            if from_stop_time.stop_order <= stop_time.stop_order <= to_stop_time.stop_order
        ]

        departures.append(
            DepartureBetweenStopsOut(
                route_name=route.name,
                route_number=route.route_number,
                vehicle_id=vehicle.id,
                vehicle_name=f"{vehicle.vehicle_type} {vehicle.brand} {vehicle.model}",
                from_stop=from_stop_name,
                to_stop=to_stop_name,
                departure_time=_format_time(from_stop_time.departure_time),
                arrival_time=_format_time(to_stop_time.arrival_time),
                stops=segment_stops,
            )
        )

    return departures
