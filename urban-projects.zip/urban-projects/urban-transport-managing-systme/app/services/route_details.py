from datetime import date, datetime, time

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import joinedload

from app.db.initial_models import Route, RouteStop, Schedule, Stop


def _format_time(value: time | None) -> str | None:
    return value.isoformat() if value else None


def _time_to_minutes(value: time) -> int:
    return value.hour * 60 + value.minute


async def get_average_delay(db: AsyncSession, route_id: int) -> float:
    result = await db.execute(
        select(Schedule)
        .where(Schedule.route_id == route_id)
        .order_by(Schedule.departure_time.desc())
        .limit(10)
    )
    schedules = result.scalars().all()

    total_delay = 0.0
    count = 0
    for schedule in schedules:
        if schedule.actual_arrival_time:
            dt_actual = datetime.combine(date.today(), schedule.actual_arrival_time)
            dt_expected = datetime.combine(date.today(), schedule.arrival_time)
            total_delay += (dt_actual - dt_expected).total_seconds() / 60
            count += 1

    return total_delay / count if count > 0 else 0.0


def _pick_upcoming_schedules(
    schedules: list[Schedule],
    limit: int = 4,
) -> list[Schedule]:
    if not schedules:
        return []

    sorted_schedules = sorted(schedules, key=lambda s: _time_to_minutes(s.departure_time))
    now_minutes = _time_to_minutes(datetime.now().time())

    upcoming = [
        schedule
        for schedule in sorted_schedules
        if _time_to_minutes(schedule.departure_time) >= now_minutes
    ]
    if len(upcoming) < limit:
        upcoming.extend(sorted_schedules[: limit - len(upcoming)])

    return upcoming[:limit]


async def get_route_details_by_number(
    db: AsyncSession,
    route_number: str,
    upcoming_schedules_limit: int = 4,
) -> dict | None:
    route_result = await db.execute(
        select(Route)
        .options(joinedload(Route.schedules).joinedload(Schedule.vehicle))
        .where(Route.route_number == route_number)
    )
    route = route_result.unique().scalar_one_or_none()
    if not route:
        return None

    stops_result = await db.execute(
        select(RouteStop, Stop)
        .join(Stop, RouteStop.stop_id == Stop.id)
        .where(RouteStop.route_id == route.id)
        .order_by(RouteStop.stop_order)
    )
    stops = [
        {
            "order": route_stop.stop_order,
            "name": stop.name,
            "latitude": stop.latitude,
            "longitude": stop.longitude,
        }
        for route_stop, stop in stops_result.all()
    ]

    upcoming = _pick_upcoming_schedules(route.schedules, limit=upcoming_schedules_limit)
    average_delay = await get_average_delay(db, route.id)

    return {
        "route_id": route.id,
        "route_number": route.route_number,
        "route_name": route.name,
        "distance_km": route.distance,
        "average_delay_minutes": average_delay,
        "stops_count": len(stops),
        "stops": stops,
        "upcoming_schedules": [
            {
                "schedule_id": schedule.id,
                "departure_time": _format_time(schedule.departure_time),
                "arrival_time": _format_time(schedule.arrival_time),
                "actual_arrival_time": _format_time(schedule.actual_arrival_time),
                "delay_minutes": schedule.delay_minutes,
                "vehicle": {
                    "id": schedule.vehicle.id,
                    "type": schedule.vehicle.vehicle_type,
                    "registration_number": schedule.vehicle.registration_number,
                    "brand": schedule.vehicle.brand,
                    "model": schedule.vehicle.model,
                    "capacity": schedule.vehicle.capacity,
                },
            }
            for schedule in upcoming
        ],
    }
