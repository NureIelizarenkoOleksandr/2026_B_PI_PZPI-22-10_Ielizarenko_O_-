import logging

from fastapi import WebSocket
from starlette.websockets import WebSocketDisconnect, WebSocketState

from app.db.initial_models import User

logger = logging.getLogger(__name__)


def user_group_key(user: User) -> str:
    role = user.role.value if hasattr(user.role, "value") else str(user.role)
    return f"{role}:{user.id}"


class GroupManager:
    def __init__(self) -> None:
        self._groups: dict[str, set[WebSocket]] = {}
        self._membership: dict[WebSocket, set[str]] = {}

    async def connect(self, websocket: WebSocket) -> None:
        await websocket.accept()

    def group_add(self, group: str, websocket: WebSocket) -> None:
        self._groups.setdefault(group, set()).add(websocket)
        self._membership.setdefault(websocket, set()).add(group)
        logger.debug("Added websocket to group %s (size=%s)", group, self.group_count(group))

    def group_discard(self, group: str, websocket: WebSocket) -> None:
        members = self._groups.get(group)
        if members is not None:
            members.discard(websocket)
            if not members:
                del self._groups[group]

        membership = self._membership.get(websocket)
        if membership is not None:
            membership.discard(group)
            if not membership:
                del self._membership[websocket]

    def group_count(self, group: str) -> int:
        return len(self._groups.get(group, set()))

    def get_groups(self, websocket: WebSocket) -> set[str]:
        return set(self._membership.get(websocket, set()))

    def list_groups(self) -> list[str]:
        return list(self._groups.keys())

    async def send_personal(self, websocket: WebSocket, message: dict) -> bool:
        if websocket.client_state != WebSocketState.CONNECTED:
            return False
        try:
            await websocket.send_json(message)
            return True
        except (WebSocketDisconnect, RuntimeError):
            return False

    async def group_send(self, group: str, message: dict, *, exclude: WebSocket | None = None) -> int:
        delivered = 0
        dead: list[WebSocket] = []

        msg_type = message.get("type") if isinstance(message, dict) else None
        for websocket in list(self._groups.get(group, set())):
            if websocket is exclude:
                continue
            if await self.send_personal(websocket, message):
                delivered += 1
            else:
                dead.append(websocket)

        for websocket in dead:
            await self.disconnect(websocket)

        logger.info(
            "WS group_send delivered=%s group=%s type=%s total_connections=%s",
            delivered,
            group,
            msg_type,
            self.group_count(group),
        )
        return delivered

    async def disconnect(self, websocket: WebSocket) -> None:
        for group in list(self.get_groups(websocket)):
            self.group_discard(group, websocket)


group_manager = GroupManager()
