from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.shemas.chat import ChatConversationOut, ChatMessageItem
from app.db.initial_models import ChatConversation, User
from app.services.ws_groups import group_manager, user_group_key


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _message_payload(sender: User, text: str) -> dict:
    role = sender.role.value if hasattr(sender.role, "value") else str(sender.role)
    return {
        "sender_id": sender.id,
        "sender_role": role,
        "text": text,
        "sent_at": _utc_now().isoformat(),
    }


def _parse_messages(raw: list | None) -> list[ChatMessageItem]:
    if not raw:
        return []
    return [ChatMessageItem.model_validate(item) for item in raw]


def _conversation_out(conversation: ChatConversation) -> ChatConversationOut:
    return ChatConversationOut(
        id=conversation.id,
        admin_id=conversation.admin_id,
        user_id=conversation.user_id,
        messages=_parse_messages(conversation.messages),
    )


async def _get_or_create_conversation(
    db: AsyncSession,
    admin_id: int,
    user_id: int,
) -> ChatConversation:
    result = await db.execute(
        select(ChatConversation).where(
            ChatConversation.admin_id == admin_id,
            ChatConversation.user_id == user_id,
        )
    )
    conversation = result.scalar_one_or_none()
    if conversation:
        return conversation

    conversation = ChatConversation(
        admin_id=admin_id,
        user_id=user_id,
        messages=[],
    )
    db.add(conversation)
    await db.flush()
    return conversation


async def send_admin_message(
    db: AsyncSession,
    admin: User,
    user_id: int,
    text: str,
) -> ChatConversationOut:
    recipient_result = await db.execute(select(User).where(User.id == user_id))
    recipient = recipient_result.scalar_one_or_none()
    if recipient is None:
        raise ValueError("User not found")
    if recipient.id == admin.id:
        raise ValueError("Cannot send a message to yourself")

    conversation = await _get_or_create_conversation(db, admin.id, user_id)
    message = _message_payload(admin, text)
    messages = list(conversation.messages or [])
    messages.append(message)
    conversation.messages = messages

    await db.commit()
    await db.refresh(conversation)

    ws_payload = {
        "type": "chat.message",
        "conversation_id": conversation.id,
        **message,
    }
    await group_manager.group_send(user_group_key(recipient), ws_payload)

    return _conversation_out(conversation)


async def get_admin_conversation(
    db: AsyncSession,
    admin_id: int,
    user_id: int,
) -> ChatConversationOut | None:
    result = await db.execute(
        select(ChatConversation).where(
            ChatConversation.admin_id == admin_id,
            ChatConversation.user_id == user_id,
        )
    )
    conversation = result.scalar_one_or_none()
    if conversation is None:
        return None
    return _conversation_out(conversation)


async def get_user_conversation_with_admin(
    db: AsyncSession,
    user_id: int,
    admin_id: int,
) -> ChatConversationOut | None:
    # Same underlying table; just flipped perspective.
    return await get_admin_conversation(db, admin_id=admin_id, user_id=user_id)


async def get_user_conversations(
    db: AsyncSession,
    user_id: int,
) -> list[ChatConversationOut]:
    result = await db.execute(
        select(ChatConversation)
        .where(ChatConversation.user_id == user_id)
        .order_by(ChatConversation.id)
    )
    conversations = result.scalars().all()
    return [_conversation_out(conversation) for conversation in conversations]


async def get_admin_conversations(
    db: AsyncSession,
    admin_id: int,
) -> list[ChatConversationOut]:
    result = await db.execute(
        select(ChatConversation)
        .where(ChatConversation.admin_id == admin_id)
        .order_by(ChatConversation.id)
    )
    conversations = result.scalars().all()
    return [_conversation_out(conversation) for conversation in conversations]
