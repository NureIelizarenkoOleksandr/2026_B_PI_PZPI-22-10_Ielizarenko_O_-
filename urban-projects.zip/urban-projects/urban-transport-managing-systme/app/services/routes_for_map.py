from collections import defaultdict

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.shemas.routes import MapRouteOut, MapStopOut
from app.db.initial_models import Route, RouteStop, Stop


async def get_routes_for_map(db: AsyncSession) -> list[MapRouteOut]:
    routes_result = await db.execute(select(Route).order_by(Route.id))
    routes = routes_result.scalars().all()
    if not routes:
        return []

    route_ids = [route.id for route in routes]
    stops_result = await db.execute(
        select(RouteStop, Stop)
        .join(Stop, RouteStop.stop_id == Stop.id)
        .where(RouteStop.route_id.in_(route_ids))
        .order_by(RouteStop.route_id, RouteStop.stop_order)
    )

    stops_by_route: dict[int, list[MapStopOut]] = defaultdict(list)
    for route_stop, stop in stops_result.all():
        stops_by_route[route_stop.route_id].append(
            MapStopOut(
                order=route_stop.stop_order,
                id=stop.id,
                name=stop.name,
                latitude=stop.latitude,
                longitude=stop.longitude,
            )
        )

    return [
        MapRouteOut(
            id=route.id,
            route_number=route.route_number,
            name=route.name,
            distance=route.distance,
            stops=stops_by_route.get(route.id, []),
        )
        for route in routes
    ]
