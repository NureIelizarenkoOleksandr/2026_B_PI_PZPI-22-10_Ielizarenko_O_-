import logging
from functools import lru_cache

from presidio_analyzer import AnalyzerEngine, Pattern, PatternRecognizer, RecognizerResult
from presidio_analyzer.predefined_recognizers import CreditCardRecognizer
from presidio_analyzer.recognizer_registry import RecognizerRegistry

logger = logging.getLogger(__name__)

BLOCKED_ENTITIES = frozenset({"CREDIT_CARD", "UA_PASSPORT"})
BLOCK_THRESHOLD = 0.75
# Presidio registry is configured for English; regex/Luhn work on Ukrainian text too.
PRESIDIO_LANGUAGE = "en"


UA_PASSPORT_CONTEXT = [
    "паспорт",
    "passport",
    "закордонний",
    "серія",
    "номер",
    "id-картка",
    "id картка",
]


def _ua_passport_recognizer() -> PatternRecognizer:
    return PatternRecognizer(
        supported_entity="UA_PASSPORT",
        patterns=[
            Pattern(
                name="ua_passport_book",
                regex=r"\b[A-ZА-ЯІЇЄҐ]{2}\s?\d{6}\b",
                score=0.9,
            ),
        ],
        context=UA_PASSPORT_CONTEXT,
    )


def _build_analyzer() -> AnalyzerEngine:
    registry = RecognizerRegistry()
    registry.add_recognizer(CreditCardRecognizer())
    registry.add_recognizer(_ua_passport_recognizer())
    return AnalyzerEngine(registry=registry, supported_languages=["en"])


@lru_cache
def get_analyzer() -> AnalyzerEngine:
    logger.info("Initializing PII analyzer (credit card + UA passport)")
    return _build_analyzer()


def analyze_text(text: str, language: str = "uk") -> list[RecognizerResult]:
    return get_analyzer().analyze(text=text, language=PRESIDIO_LANGUAGE)


def is_blocked(text: str, language: str = "uk") -> bool:
    return any(
        r.entity_type in BLOCKED_ENTITIES and r.score >= BLOCK_THRESHOLD
        for r in analyze_text(text, language=language)
    )


def results_to_dict(results: list[RecognizerResult]) -> list[dict]:
    return [
        {
            "entity_type": r.entity_type,
            "start": r.start,
            "end": r.end,
            "score": r.score,
        }
        for r in results
    ]
