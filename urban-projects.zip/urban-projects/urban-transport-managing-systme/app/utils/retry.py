import asyncio
import functools
import logging

logger = logging.getLogger(__name__)


def retry(times, exceptions):
    def decorator(func):
        if asyncio.iscoroutinefunction(func):

            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                attempt = 0
                while attempt < times:
                    try:
                        return await func(*args, **kwargs)
                    except exceptions:
                        logger.exception(
                            "Exception thrown when attempting to run %s, attempt %d of %d",
                            func,
                            attempt + 1,
                            times,
                        )
                        attempt += 1
                return await func(*args, **kwargs)

            return async_wrapper

        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            attempt = 0
            while attempt < times:
                try:
                    return func(*args, **kwargs)
                except exceptions:
                    logger.exception(
                        "Exception thrown when attempting to run %s, attempt %d of %d",
                        func,
                        attempt + 1,
                        times,
                    )
                    attempt += 1
            return func(*args, **kwargs)

        return sync_wrapper

    return decorator
