import json
import logging
from typing import Any

from app.api.core.config import settings
from app.redis.client import redis_client

logger = logging.getLogger(__name__)

CHAT_KEY_PREFIX = "user:chat:"


def chat_key(user_id: int) -> str:
    return f"{CHAT_KEY_PREFIX}{user_id}"


async def get_history(user_id: int) -> list[dict[str, Any]]:
    raw = await redis_client.get(chat_key(user_id))
    if not raw:
        return []
    return json.loads(raw)


async def set_history(user_id: int, messages: list[dict[str, Any]]) -> None:
    await redis_client.set(
        chat_key(user_id),
        json.dumps(messages),
        ex=settings.CHAT_HISTORY_TTL_SECONDS,
    )


async def append_turn(
    user_id: int,
    user_message: str,
    assistant_message: str,
) -> list[dict[str, Any]]:
    history = await get_history(user_id)
    history.append({"role": "user", "content": user_message})
    history.append({"role": "assistant", "content": assistant_message})
    await set_history(user_id, history)
    logger.debug("Updated chat history for user_id=%s (%s messages)", user_id, len(history))
    return history
