import json
import logging
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from app.services.route_details import get_route_details_by_number
from app.services.route_options import get_departures_between_stops

logger = logging.getLogger(__name__)

FIND_ROUTE_OPTIONS_TOOL = {
    "type": "function",
    "function": {
        "name": "find_route_options",
        "description": (
            "Find available public transport trips between two stops by exact stop names. "
            "Returns route numbers, vehicle info, and departure/arrival times."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "from_stop_name": {
                    "type": "string",
                    "description": "Departure stop name, e.g. 'Central Station'.",
                },
                "to_stop_name": {
                    "type": "string",
                    "description": "Destination stop name, e.g. 'Airport'.",
                },
            },
            "required": ["from_stop_name", "to_stop_name"],
        },
    },
}

GET_ROUTE_DETAILS_TOOL = {
    "type": "function",
    "function": {
        "name": "get_route_details",
        "description": (
            "Get full details for a public transport route by its route number. "
            "Returns route name, distance, average delay, all stops in order, "
            "and the next upcoming schedules with vehicle info. "
            "After receiving results, summarize them for the user in clear natural language "
            "with brief explanations — do not reply with raw JSON or a dry list of fields."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "route_number": {
                    "type": "string",
                    "description": "Route number, e.g. '101' or '42'.",
                },
            },
            "required": ["route_number"],
        },
    },
}

CHAT_TOOLS = [FIND_ROUTE_OPTIONS_TOOL, GET_ROUTE_DETAILS_TOOL]


async def execute_tool(
    name: str,
    arguments: dict[str, Any],
    db: AsyncSession,
) -> dict[str, Any]:
    if name == "find_route_options":
        from_stop_name = arguments.get("from_stop_name", "").strip()
        to_stop_name = arguments.get("to_stop_name", "").strip()

        if not from_stop_name or not to_stop_name:
            return {
                "error": "Both from_stop_name and to_stop_name are required.",
            }

        options = await get_departures_between_stops(
            db,
            from_stop_name=from_stop_name,
            to_stop_name=to_stop_name,
        )
        return {
            "from_stop": from_stop_name,
            "to_stop": to_stop_name,
            "options_count": len(options),
            "options": [option.model_dump() for option in options],
        }

    if name == "get_route_details":
        route_number = arguments.get("route_number", "").strip()
        if not route_number:
            return {"error": "route_number is required."}

        details = await get_route_details_by_number(db, route_number=route_number)
        if details is None:
            return {
                "error": f"Route '{route_number}' was not found.",
                "route_number": route_number,
            }
        return details

    logger.warning("Unknown tool requested: %s", name)
    return {"error": f"Unknown tool: {name}"}


def serialize_tool_result(result: dict[str, Any]) -> str:
    return json.dumps(result, ensure_ascii=False, default=str)
