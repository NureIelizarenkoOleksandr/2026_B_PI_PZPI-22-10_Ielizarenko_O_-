import json
import logging
from collections.abc import AsyncGenerator, Awaitable, Callable
from functools import cached_property
from typing import Any

from openai import AsyncOpenAI, InternalServerError

from app.api.core.config import settings
from app.utils.retry import retry

logger = logging.getLogger(__name__)

INPUT_TOKEN_PRICE = 0.15 / 1_000_000
OUTPUT_TOKEN_PRICE = 0.60 / 1_000_000


def _log_usage(usage) -> None:
    if not usage:
        logger.warning("LLM response has no usage data")
        return

    input_tokens = usage.prompt_tokens or 0
    output_tokens = usage.completion_tokens or 0

    cached_tokens = 0

    details = getattr(usage, "prompt_tokens_details", None)
    if details:
        cached_tokens = getattr(details, "cached_tokens", 0) or 0

    cost = (
        input_tokens * INPUT_TOKEN_PRICE
        + output_tokens * OUTPUT_TOKEN_PRICE
    )

    logger.info(
        (
            "LLM usage: "
            "input_tokens=%s "
            "output_tokens=%s "
            "cached_tokens=%s "
            "cache_hit=%s "
            "cost=$%.8f"
        ),
        input_tokens,
        output_tokens,
        cached_tokens,
        cached_tokens > 0,
        cost,
    )

class AIHandler:
    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        model: str | None = None,
    ):
        self.model = model or settings.OPENAI_MODEL
        self._api_key = api_key or settings.OPENAI_API_KEY
        self._base_url = base_url or settings.OPENAI_BASE_URL or None

    @cached_property
    def client(self) -> AsyncOpenAI:
        if not self._api_key:
            raise RuntimeError("OPENAI_API_KEY is not configured")
        return AsyncOpenAI(
            api_key=self._api_key,
            base_url=self._base_url,
        )

    @retry(times=3, exceptions=InternalServerError)
    async def _create_completion(self, messages: list, **kwargs):
        return await self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            **kwargs,
        )

    async def run_messages(self, messages: list[dict]) -> str:
        response = await self._create_completion(messages)
        _log_usage(response.usage)
        return response.choices[0].message.content or ""

    async def _run_tool_loop(
        self,
        messages: list[dict],
        tools: list[dict],
        tool_executor: Callable[[str, dict[str, Any]], Awaitable[Any]],
        max_rounds: int = 5,
    ) -> str:
        working_messages = list(messages)

        for _ in range(max_rounds):
            response = await self._create_completion(
                working_messages,
                tools=tools,
                tool_choice="auto",
            )
            _log_usage(response.usage)

            message = response.choices[0].message
            if not message.tool_calls:
                return message.content or ""

            working_messages.append(message.model_dump(exclude_none=True))

            for tool_call in message.tool_calls:
                arguments = json.loads(tool_call.function.arguments or "{}")
                result = await tool_executor(
                    tool_call.function.name,
                    arguments,
                )
                working_messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": tool_call.id,
                        "content": json.dumps(result, ensure_ascii=False, default=str),
                    }
                )

        raise RuntimeError("Tool call limit exceeded")

    async def run_messages_with_tools(
        self,
        messages: list[dict],
        tools: list[dict],
        tool_executor: Callable[[str, dict[str, Any]], Awaitable[Any]],
    ) -> str:
        return await self._run_tool_loop(messages, tools, tool_executor)

    async def run_stream_messages_with_tools(
        self,
        messages: list[dict],
        tools: list[dict],
        tool_executor: Callable[[str, dict[str, Any]], Awaitable[Any]],
    ) -> AsyncGenerator[str, None]:
        content = await self._run_tool_loop(messages, tools, tool_executor)
        if content:
            yield content

    async def run_stream_messages(self, messages: list[dict]) -> AsyncGenerator[str, None]:
        stream = await self._create_completion(
            messages,
            stream=True,
            stream_options={"include_usage": True},
        )

        usage = None
        async for chunk in stream:
            if chunk.usage:
                usage = chunk.usage

            if not chunk.choices:
                continue

            delta = chunk.choices[0].delta.content
            if delta:
                yield delta

        _log_usage(usage)


ai_handler = AIHandler()
