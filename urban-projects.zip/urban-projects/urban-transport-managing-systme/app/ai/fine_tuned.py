import asyncio
import logging

import modal

from app.api.core.config import settings

logger = logging.getLogger(__name__)

_END_OF_TEXT = "<|end_of_text|>"


def _clean_response(text: str) -> str:
    return text.replace(_END_OF_TEXT, "").strip()


def _get_pricer():
    Pricer = modal.Cls.from_name(settings.MODAL_APP_NAME, settings.MODAL_CLASS_NAME)
    return Pricer()


def predict(description: str) -> str:
    logger.info(
        "Calling Modal %s.%s.predict",
        settings.MODAL_APP_NAME,
        settings.MODAL_CLASS_NAME,
    )
    pricer = _get_pricer()
    return _clean_response(pricer.predict.remote(description))


async def predict_async(description: str) -> str:
    return await asyncio.to_thread(predict, description)


def get_model_status() -> dict:
    return {
        "backend": "modal",
        "app_name": settings.MODAL_APP_NAME,
        "class_name": settings.MODAL_CLASS_NAME,
    }
