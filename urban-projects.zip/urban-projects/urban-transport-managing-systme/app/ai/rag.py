import logging
from typing import Any

from RAG.build_vectors import query_index
from RAG.chroma_store import document_count

logger = logging.getLogger(__name__)

BASE_SYSTEM_PROMPT = """You are an assistant for the urban public transport management system.
Use the context below when it is relevant to the user's question.
If the context does not contain the answer, say so clearly and do not invent facts.
Reply in the same language the user writes in (Ukrainian or English).

Strict grounding rules:
- Answer ONLY with facts from tool results or the RAG context below.
- Do NOT invent or assume: mobile apps, SMS services, phone numbers, websites, ticket prices,
  peak-hour rules, or generic passenger tips unless they appear explicitly in context or tool data.
- Do NOT add emojis or marketing-style closings.
- If tool data is insufficient, say what is missing instead of filling gaps with guesses.

When the user asks how to get from one stop to another, which routes or trips are available,
or what transport options exist between two stations, call the find_route_options tool with
exact stop names in English as stored in the system (e.g. "Central Station", "Park").
Do not guess route times, vehicles, or stops without tool data.

When the user asks about a specific route number (e.g. "route 101", "маршрут 42"), its stops,
schedule, delays, or general route information, call the get_route_details tool with that route
number. After the tool returns data, analyze it and answer in a human-readable style:
- Start with a short overview (route name, what it connects, distance if provided).
- Describe the stop sequence as a journey, not as a raw table.
- List departures/arrivals and vehicles exactly as returned by the tool.
- Comment on average delay only if the tool returned average_delay_minutes.
- Use short paragraphs or bullets; avoid dumping JSON, IDs, or unexplained field names.
Do not invent route facts without tool data.
"""

RAG_TOP_K = 3
ALLOWED_HISTORY_ROLES = frozenset({"user", "assistant"})


def retrieve_context(query: str, top_k: int = RAG_TOP_K) -> str:
    if document_count() == 0:
        logger.warning("ChromaDB collection is empty; skipping RAG retrieval")
        return ""

    results = query_index(query, top_k=top_k)
    documents = results.get("documents", [[]])[0]
    metadatas = results.get("metadatas", [[]])[0]
    if not documents:
        return ""

    blocks: list[str] = []
    for doc, meta in zip(documents, metadatas):
        source = (meta or {}).get("source", "unknown")
        blocks.append(f"[{source}]\n{doc}")
    return "\n\n---\n\n".join(blocks)


def build_system_prompt(user_message: str, top_k: int = RAG_TOP_K) -> str:
    context = retrieve_context(user_message, top_k=top_k)
    if not context:
        return BASE_SYSTEM_PROMPT.strip()
    return f"{BASE_SYSTEM_PROMPT.strip()}\n\n# Context\n{context}"


def build_chat_messages(
    user_message: str,
    history: list[dict[str, Any]] | None = None,
    top_k: int = RAG_TOP_K,
) -> list[dict[str, str]]:
    """
    system (with RAG context) + history (user/assistant only) + current user message.
    Not persisted to Redis — only user/assistant turns are stored in chat history.
    """
    messages: list[dict[str, str]] = [
        {"role": "system", "content": build_system_prompt(user_message, top_k=top_k)},
    ]

    for entry in history or []:
        role = entry.get("role")
        content = entry.get("content")
        if role in ALLOWED_HISTORY_ROLES and content:
            messages.append({"role": role, "content": content})

    messages.append({"role": "user", "content": user_message})
    return messages
