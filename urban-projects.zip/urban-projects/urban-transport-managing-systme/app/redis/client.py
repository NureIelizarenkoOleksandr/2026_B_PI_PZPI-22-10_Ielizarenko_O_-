from redis.asyncio import Redis

from app.api.core.config import settings

redis_client: Redis = Redis.from_url(
    settings.redis_url,
    decode_responses=True,
)


async def close_redis_client() -> None:
    await redis_client.aclose()
