from datetime import datetime, time, timedelta
import hashlib

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.initial_models import Route, RouteStop, Schedule, Stop, StopTime, Vehicle, User
from app.db.session import get_db
from app.db.user_role import UserRole

router = APIRouter()


def _add_minutes(value: time, minutes: int) -> time:
    base = datetime.combine(datetime.today(), value) + timedelta(minutes=minutes)
    return base.time()


def _build_stop_times(
    schedule_id: int,
    stop_chain: list[int],
    start: time,
    leg_minutes: int = 12,
    dwell_minutes: int = 5,
) -> list[StopTime]:
    rows: list[StopTime] = []
    current = start
    for order, stop_id in enumerate(stop_chain, start=1):
        arrival = current
        departure = _add_minutes(arrival, dwell_minutes) if order < len(stop_chain) else arrival
        rows.append(
            StopTime(
                schedule_id=schedule_id,
                stop_id=stop_id,
                arrival_time=arrival,
                departure_time=departure,
                stop_order=order,
            )
        )
        current = _add_minutes(departure, leg_minutes)
    return rows


async def seed_test_data(db: AsyncSession) -> dict[str, int]:
    stops = [
        Stop(id=1, name="Central Station", latitude=50.4501, longitude=30.5234),
        Stop(id=2, name="Main Square", latitude=50.4505, longitude=30.5240),
        Stop(id=3, name="Park", latitude=50.4490, longitude=30.5200),
        Stop(id=4, name="Airport", latitude=50.4310, longitude=30.5150),
        Stop(id=5, name="University", latitude=50.4470, longitude=30.5180),
        Stop(id=6, name="Museum", latitude=50.4480, longitude=30.5210),
        Stop(id=7, name="Hospital", latitude=50.4495, longitude=30.5225),
        Stop(id=8, name="Library", latitude=50.4510, longitude=30.5250),
        Stop(id=9, name="City Hall", latitude=50.4520, longitude=30.5270),
        Stop(id=10, name="Stadium", latitude=50.4530, longitude=30.5280),
        Stop(id=11, name="Market", latitude=50.4515, longitude=30.5195),
        Stop(id=12, name="River Port", latitude=50.4465, longitude=30.5165),
    ]
    db.add_all(stops)
    await db.flush()

    routes = [
        Route(id=1, route_number="101", name="Downtown Loop", distance=12.5),
        Route(id=2, route_number="102", name="Airport Express", distance=25.0),
        Route(id=3, route_number="103", name="University Shuttle", distance=8.0),
        Route(id=4, route_number="22", name="Tram Khreschatyk - River Port", distance=9.4),
        Route(id=5, route_number="45", name="Night Stadium Shuttle", distance=14.2),
    ]
    db.add_all(routes)
    await db.flush()

    vehicles = [
        Vehicle(id=1, vehicle_type="Bus", registration_number="AB1234CD", brand="Volvo", model="7700", capacity=50),
        Vehicle(id=2, vehicle_type="Tram", registration_number="TR5678EF", brand="Siemens", model="Avenio", capacity=120),
        Vehicle(id=3, vehicle_type="Minibus", registration_number="MB9012GH", brand="Mercedes", model="Sprinter", capacity=20),
        Vehicle(id=4, vehicle_type="Bus", registration_number="KA1111AA", brand="MAN", model="Lion's City", capacity=80),
        Vehicle(id=5, vehicle_type="Trolleybus", registration_number="TB2222BB", brand="Skoda", model="26Tr", capacity=95),
        Vehicle(id=6, vehicle_type="Tram", registration_number="TR3333CC", brand="Alstom", model="Citadis", capacity=110),
    ]
    db.add_all(vehicles)
    await db.flush()

    route_stop_chains = {
        1: [1, 2, 6, 7, 8, 9, 10, 5, 3, 1],
        2: [4, 3, 2, 1],
        3: [5, 6, 7, 8, 2, 1],
        4: [1, 2, 11, 12, 3],
        5: [1, 9, 10, 4],
    }
    route_stops = [
        RouteStop(route_id=route_id, stop_id=stop_id, stop_order=order)
        for route_id, chain in route_stop_chains.items()
        for order, stop_id in enumerate(chain, start=1)
    ]
    db.add_all(route_stops)
    await db.flush()

    schedules = [
        Schedule(id=1, route_id=1, vehicle_id=1, departure_time=time(6, 30), arrival_time=time(8, 15),
                 actual_arrival_time=time(8, 22), delay_minutes=7),
        Schedule(id=2, route_id=1, vehicle_id=2, departure_time=time(8, 0), arrival_time=time(9, 45),
                 actual_arrival_time=time(9, 45), delay_minutes=0),
        Schedule(id=3, route_id=1, vehicle_id=4, departure_time=time(12, 0), arrival_time=time(13, 45),
                 actual_arrival_time=time(13, 58), delay_minutes=13),
        Schedule(id=4, route_id=1, vehicle_id=1, departure_time=time(16, 0), arrival_time=time(17, 45)),
        Schedule(id=5, route_id=1, vehicle_id=2, departure_time=time(18, 30), arrival_time=time(20, 15),
                 actual_arrival_time=time(20, 9), delay_minutes=-6),
        Schedule(id=6, route_id=2, vehicle_id=3, departure_time=time(5, 45), arrival_time=time(6, 55),
                 actual_arrival_time=time(7, 3), delay_minutes=8),
        Schedule(id=7, route_id=2, vehicle_id=3, departure_time=time(9, 30), arrival_time=time(10, 40)),
        Schedule(id=8, route_id=2, vehicle_id=4, departure_time=time(14, 15), arrival_time=time(15, 25),
                 actual_arrival_time=time(15, 20), delay_minutes=-5),
        Schedule(id=9, route_id=2, vehicle_id=3, departure_time=time(19, 0), arrival_time=time(20, 10)),
        Schedule(id=10, route_id=3, vehicle_id=5, departure_time=time(7, 15), arrival_time=time(8, 35),
                  actual_arrival_time=time(8, 41), delay_minutes=6),
        Schedule(id=11, route_id=3, vehicle_id=5, departure_time=time(11, 30), arrival_time=time(12, 50)),
        Schedule(id=12, route_id=3, vehicle_id=3, departure_time=time(17, 0), arrival_time=time(18, 20),
                  actual_arrival_time=time(18, 35), delay_minutes=15),
        Schedule(id=13, route_id=4, vehicle_id=6, departure_time=time(6, 0), arrival_time=time(7, 5),
                  actual_arrival_time=time(7, 2), delay_minutes=-3),
        Schedule(id=14, route_id=4, vehicle_id=2, departure_time=time(10, 20), arrival_time=time(11, 25)),
        Schedule(id=15, route_id=4, vehicle_id=6, departure_time=time(15, 10), arrival_time=time(16, 15),
                  actual_arrival_time=time(16, 24), delay_minutes=9),
        Schedule(id=16, route_id=4, vehicle_id=2, departure_time=time(20, 0), arrival_time=time(21, 5)),
        Schedule(id=17, route_id=5, vehicle_id=4, departure_time=time(22, 0), arrival_time=time(23, 10)),
        Schedule(id=18, route_id=5, vehicle_id=1, departure_time=time(23, 30), arrival_time=time(0, 35)),
    ]
    db.add_all(schedules)
    await db.flush()

    schedule_chains = {
        1: (route_stop_chains[1], time(6, 30), 10),
        2: (route_stop_chains[1], time(8, 0), 10),
        3: (route_stop_chains[1], time(12, 0), 10),
        4: (route_stop_chains[1], time(16, 0), 10),
        5: (route_stop_chains[1], time(18, 30), 10),
        6: (route_stop_chains[2], time(5, 45), 15),
        7: (route_stop_chains[2], time(9, 30), 15),
        8: (route_stop_chains[2], time(14, 15), 15),
        9: (route_stop_chains[2], time(19, 0), 15),
        10: (route_stop_chains[3], time(7, 15), 12),
        11: (route_stop_chains[3], time(11, 30), 12),
        12: (route_stop_chains[3], time(17, 0), 12),
        13: (route_stop_chains[4], time(6, 0), 11),
        14: (route_stop_chains[4], time(10, 20), 11),
        15: (route_stop_chains[4], time(15, 10), 11),
        16: (route_stop_chains[4], time(20, 0), 11),
        17: (route_stop_chains[5], time(22, 0), 14),
        18: (route_stop_chains[5], time(23, 30), 14),
    }

    stop_times: list[StopTime] = []
    for schedule_id, (chain, start, leg_minutes) in schedule_chains.items():
        stop_times.extend(_build_stop_times(schedule_id, chain, start, leg_minutes=leg_minutes))

    db.add_all(stop_times)
    await db.commit()

    return {
        "stops": len(stops),
        "routes": len(routes),
        "vehicles": len(vehicles),
        "route_stops": len(route_stops),
        "schedules": len(schedules),
        "stop_times": len(stop_times),
    }


@router.post("/seed")
async def run_seed(db: AsyncSession = Depends(get_db)):
    try:
        counts = await seed_test_data(db)
    except IntegrityError:
        await db.rollback()
        raise HTTPException(
            status_code=409,
            detail="Test data already exists. Clear the database before seeding again.",
        )

    return {
        "status": "ok",
        "message": "Test data seeded",
        "counts": counts,
        "examples": {
            "route_by_number": "/routes/routes/by-number/101",
            "departures": "/routes/departures-between-stops/Central Station/Airport",
            "ai_tools": ["get_route_details", "find_route_options"],
        },
    }


def _hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()


@router.post("/seed-users")
async def seed_test_users(db: AsyncSession = Depends(get_db)):
    """
    Create demo users with different roles.

    All users share the same password: `password123`
    """
    password = _hash_password("password123")

    users = [
        User(email="admin@utms.local", username="admin", password=password, role=UserRole.admin),
        User(email="driver1@utms.local", username="driver1", password=password, role=UserRole.driver),
        User(email="driver2@utms.local", username="driver2", password=password, role=UserRole.driver),
        User(email="user@utms.local", username="user", password=password, role=UserRole.user),
    ]

    try:
        db.add_all(users)
        await db.commit()
    except IntegrityError:
        await db.rollback()
        raise HTTPException(
            status_code=409,
            detail="Test users already exist. Clear the database before seeding again.",
        )

    return {
        "status": "ok",
        "message": "Test users seeded",
        "counts": {"users": len(users)},
        "password": "password123",
        "examples": {
            "login_admin": {"username": "admin@utms.local", "password": "password123"},
            "login_driver": {"username": "driver1@utms.local", "password": "password123"},
        },
    }
