import logging

from fastapi import APIRouter, Depends, WebSocket, WebSocketDisconnect
from jose import JWTError, jwt
from pydantic import ValidationError
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.endpoints.auth import ALGORITHM, SECRET_KEY, get_current_admin, get_user
from app.api.shemas.ws import WSConnectedOut, WSErrorOut, WSMessageIn, WSMessageOut
from app.db.initial_models import User
from app.db.session import get_db
from app.services.ws_groups import group_manager, user_group_key

logger = logging.getLogger(__name__)

router = APIRouter()

_RED = "\x1b[31m"
_RESET = "\x1b[0m"

@router.get("/debug/groups")
async def debug_ws_groups(_admin: User = Depends(get_current_admin)):
    groups = group_manager.list_groups()
    return {
        "groups": [
            {"group": group, "connections": group_manager.group_count(group)}
            for group in groups
        ],
        "total_groups": len(groups),
    }


def _extract_bearer_token(websocket: WebSocket) -> str | None:
    authorization = websocket.headers.get("authorization")
    if authorization and authorization.lower().startswith("bearer "):
        return authorization[7:].strip()
    return websocket.query_params.get("token")


async def _authenticate_websocket(websocket: WebSocket, db: AsyncSession) -> User | None:
    token = _extract_bearer_token(websocket)
    if not token:
        return None

    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        email = payload.get("sub")
        if not email:
            return None
    except JWTError:
        return None

    return await get_user(db, email=email)


@router.websocket("/connect")
async def websocket_connect(
    websocket: WebSocket,
    db: AsyncSession = Depends(get_db),
) -> None:
    user = await _authenticate_websocket(websocket, db)
    if user is None:
        logger.warning("%sWS connect rejected (no/invalid token)%s", _RED, _RESET)
        await websocket.close(code=4401, reason="Invalid or missing bearer token")
        return

    await group_manager.connect(websocket)
    websocket.state.user = user

    group = user_group_key(user)
    group_manager.group_add(group, websocket)
    logger.info(
        "%sWS connected user_id=%s role=%s group=%s connections_in_group=%s%s",
        _RED,
        user.id,
        getattr(user.role, "value", user.role),
        group,
        group_manager.group_count(group),
        _RESET,
    )

    await group_manager.send_personal(
        websocket,
        WSConnectedOut(
            group=group,
            user_id=user.id,
            role=user.role,
            connections_in_group=group_manager.group_count(group),
        ).model_dump(),
    )

    try:
        while True:
            try:
                raw = await websocket.receive_json()
            except (WebSocketDisconnect, RuntimeError):
                # Starlette raises RuntimeError when the socket is already closed.
                break
            try:
                message = WSMessageIn.model_validate(raw)
            except ValidationError as exc:
                await group_manager.send_personal(
                    websocket,
                    WSErrorOut(detail=str(exc.errors()[0]["msg"])).model_dump(),
                )
                continue

            outgoing = WSMessageOut(
                group=group,
                sender_id=user.id,
                sender_role=user.role,
                text=message.text,
            )
            await group_manager.group_send(group, outgoing.model_dump())
    except WebSocketDisconnect:
        logger.debug("WebSocket disconnected for user_id=%s group=%s", user.id, group)
    finally:
        logger.info(
            "%sWS disconnect cleanup user_id=%s role=%s group=%s (before_count=%s)%s",
            _RED,
            user.id,
            getattr(user.role, "value", user.role),
            group,
            group_manager.group_count(group),
            _RESET,
        )
        await group_manager.disconnect(websocket)
