import json

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.ai.fine_tuned import get_model_status, predict_async
from app.ai.handler import ai_handler
from app.ai.rag import build_chat_messages
from app.ai.tools import CHAT_TOOLS, execute_tool
from app.api.core.config import settings
from app.api.endpoints.auth import get_current_user
from app.db.initial_models import User
from app.db.session import get_db
from app.utils.chat_history import append_turn, get_history

router = APIRouter()


class AIRunRequest(BaseModel):
    message: str


class FineTunedRunRequest(BaseModel):
    description: str


def _make_tool_executor(db: AsyncSession):
    async def tool_executor(name: str, arguments: dict):
        return await execute_tool(name, arguments, db)

    return tool_executor


@router.post("/run")
async def run_ai(
    request: AIRunRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    history = await get_history(current_user.id)
    messages = build_chat_messages(request.message, history=history)
    tool_executor = _make_tool_executor(db)
    response = await ai_handler.run_messages_with_tools(
        messages,
        tools=CHAT_TOOLS,
        tool_executor=tool_executor,
    )
    await append_turn(current_user.id, request.message, response)
    return {"response": response}


@router.get("/finetuned/status")
async def finetuned_model_status(
    current_user: User = Depends(get_current_user),
):
    return get_model_status()


@router.post("/finetuned/run")
async def run_finetuned_model(
    request: FineTunedRunRequest,
    current_user: User = Depends(get_current_user),
):
    if not request.description.strip():
        raise HTTPException(status_code=400, detail="description is required")

    try:
        response = await predict_async(request.description)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc

    return {
        "response": response,
        "backend": "modal",
        "app": settings.MODAL_APP_NAME,
        "class": settings.MODAL_CLASS_NAME,
    }


@router.post("/run/stream")
async def run_ai_stream(
    request: AIRunRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    history = await get_history(current_user.id)
    user_id = current_user.id
    message = request.message
    messages = build_chat_messages(message, history=history)
    tool_executor = _make_tool_executor(db)

    async def event_generator():
        parts: list[str] = []
        try:
            async for chunk in ai_handler.run_stream_messages_with_tools(
                messages,
                tools=CHAT_TOOLS,
                tool_executor=tool_executor,
            ):
                parts.append(chunk)
                yield f"data: {json.dumps({'content': chunk})}\n\n"
        except Exception as exc:
            yield f"data: {json.dumps({'error': str(exc)})}\n\n"
            return

        await append_turn(user_id, message, "".join(parts))
        yield f"data: {json.dumps({'done': True})}\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
