from fastapi import APIRouter, Depends
from fastapi_pagination import Page
from fastapi_pagination.ext.sqlalchemy import paginate
from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.endpoints.auth import get_current_admin
from app.api.shemas.users import UserOut
from app.db.initial_models import User
from app.db.session import get_db
from app.db.user_role import UserRole

router = APIRouter()


@router.get("", response_model=Page[UserOut])
async def list_users(
    role: UserRole | None = None,
    q: str | None = None,
    db: AsyncSession = Depends(get_db),
    _admin: User = Depends(get_current_admin),
):
    query = select(User).order_by(User.id)
    if role is not None:
        query = query.where(User.role == role)
    if q:
        q = q.strip()
        if q:
            pattern = f"%{q}%"
            query = query.where(
                or_(
                    User.email.ilike(pattern),
                    User.username.ilike(pattern),
                )
            )
    return await paginate(db, query)

