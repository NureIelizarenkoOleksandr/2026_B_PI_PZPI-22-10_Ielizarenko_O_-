from fastapi import APIRouter
from pydantic import BaseModel
from sqlalchemy import text

from app.db.session import engine
from app.neo4j.client import driver
from app.utils.pii import BLOCKED_ENTITIES, BLOCK_THRESHOLD, analyze_text, results_to_dict

router = APIRouter()


class PIIAnalyzeRequest(BaseModel):
    text: str
    language: str = "uk"


@router.get("/health/db")
async def check_db_connection():
    try:
        async with engine.connect() as conn:
            await conn.execute(text("SELECT 1"))
        return {"status": "ok", "database": "connected"}
    except Exception as e:
        return {"status": "error", "database": "disconnected", "detail": str(e)}


@router.get("/health/neo4j")
async def check_neo4j_connection():
    try:
        await driver.verify_connectivity()
        return {"status": "ok", "database": "connected"}
    except Exception as e:
        return {"status": "error", "database": "disconnected", "detail": str(e)}


@router.post("/health/pii/analyze")
async def analyze_pii(request: PIIAnalyzeRequest):
    results = analyze_text(request.text, language=request.language)
    blocked = any(
        r.entity_type in BLOCKED_ENTITIES and r.score >= BLOCK_THRESHOLD
        for r in results
    )
    return {
        "blocked": blocked,
        "blocked_entities": sorted(BLOCKED_ENTITIES),
        "block_threshold": BLOCK_THRESHOLD,
        "entities": results_to_dict(results),
    }
