from random import uniform

from fastapi import APIRouter, Depends, HTTPException
from fastapi_pagination import Page
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import joinedload

from app.api.core.config import settings
from app.api.endpoints.auth import get_current_user
from app.api.shemas.routes import (
    RouteOut,
    AverageDelayResponse,
    DetailedRouteOut,
    CreateRoute,
    MapRouteOut,
    DepartureBetweenStopsOut,
)
from app.crud.routes import CRUDRoutes, crud_routes
from app.db.initial_models import Schedule, Route, User
from app.db.session import get_db
from app.services.route_details import (
    get_average_delay as calculate_average_delay,
    get_route_details_by_number,
)
from app.services.route_options import get_departures_between_stops
from app.services.routes_for_map import get_routes_for_map

router = APIRouter()

@router.get("/test")
def test():
    return {"msg": "Hello World"}

@router.get("/db/url")
def get_db_url():
    return [settings.sqlalchemy_database_url, settings.sqlalchemy_sync_database_url]

@router.get("/routes", response_model=Page[RouteOut]
            )
async def get_routes(
    current_user: User = Depends(get_current_user)
):
    result = await crud_routes.get_all()
    return result


@router.get("/for-map", response_model=list[MapRouteOut])
async def get_routes_for_map_endpoint(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return await get_routes_for_map(db)


@router.get("/routes/by-number/{route_number}")
async def get_route_by_number(
    route_number: str,
    upcoming_schedules_limit: int = 4,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    details = await get_route_details_by_number(
        db,
        route_number=route_number,
        upcoming_schedules_limit=upcoming_schedules_limit,
    )
    if details is None:
        raise HTTPException(status_code=404, detail=f"Route '{route_number}' not found")
    return details


@router.get("/routes/{route_id}/average-delay", response_model=AverageDelayResponse)
async def get_route_average_delay(route_id: int, db: AsyncSession = Depends(get_db), current_user: User = Depends(get_current_user)):
    query = select(Route).where(Route.id == route_id)
    result = await db.execute(query)
    route = result.scalar_one_or_none()
    if not route:
        raise HTTPException(status_code=404, detail="Route not found")
    avg_delay = await calculate_average_delay(db, route_id)
    return {"route_id": route_id, "route_name": route.name, "average_delay_minutes": avg_delay}


@router.get("/routes/{route_id}", response_model=DetailedRouteOut)
async def get_route(route_id: int, db: AsyncSession = Depends(get_db), current_user: User = Depends(get_current_user)):
    query = select(Route).options(
        joinedload(Route.schedules).joinedload(Schedule.vehicle)
    ).where(Route.id == route_id)
    result = await db.execute(query)
    route = result.unique().scalar_one_or_none()
    print(route.__dict__["schedules"][0].__dict__)
    avg_delay = await calculate_average_delay(db, route_id)
    if not route:
        raise HTTPException(status_code=404, detail="Route not found")

    result = DetailedRouteOut.model_validate(route)
    result.average_delay_minutes = avg_delay

    return result


# @router.post("/routes", response_model=RouteOut)
# async def create_route(route: CreateRoute, db: AsyncSession = Depends(get_db)):
#     new_route = Route(
#         route_number=route.route_number,
#         name=route.name,
#         distance=route.distance
#     )
#     db.add(new_route)
#     await db.commit()
#     await db.refresh(new_route)
#     return new_route
#
#
# @router.put("/routes/{route_id}", response_model=Route)
# async def update_route(route_id: int, route: CreateRoute, db: AsyncSession = Depends(get_db)):
#     stmt = (
#         update(Route)
#         .where(Route.id == route_id)
#         .values(**route.model_dump(exclude_unset=True))
#         .execution_options(synchronize_session="fetch")
#     )
#
#     result = await db.execute(stmt)
#     await db.commit()
#
#     if result.rowcount == 0:
#         raise HTTPException(status_code=404, detail="Route not found")
#
#     updated_route = await db.execute(select(Route).where(Route.id == route_id))
#     return updated_route.scalars().first()
#
#
# @router.delete("/routes/{route_id}")
# async def delete_route(route_id: int, db: AsyncSession = Depends(get_db)):
#     query = select(Route).where(Route.id == route_id)
#     result = await db.execute(query)
#     existing_route = result.scalars().first()
#     if not existing_route:
#         raise HTTPException(status_code=404, detail="Route not found")
#
#     await db.delete(existing_route)
#     await db.commit()
#     return {"detail": "Route deleted"}

@router.get(
    "/departures-between-stops/{from_stop_name}/{to_stop_name}",
    response_model=list[DepartureBetweenStopsOut],
)
async def get_departures_between_stops_endpoint(
    from_stop_name: str,
    to_stop_name: str,
    db: AsyncSession = Depends(get_db),
):
    return await get_departures_between_stops(
        db,
        from_stop_name=from_stop_name,
        to_stop_name=to_stop_name,
    )

CITIES = {
    1: {"name": "Kyiv", "lat_min": 50.35, "lat_max": 50.52, "lon_min": 30.4, "lon_max": 30.65},
    2: {"name": "Lviv", "lat_min": 49.78, "lat_max": 49.88, "lon_min": 23.9, "lon_max": 24.1},
}

@router.get("/vehicle/{vehicle_id}/location")
def get_random_location(vehicle_id: int):
    city = CITIES.get(vehicle_id)
    if not city:
        return {"error": "City not found"}

    lat = uniform(city["lat_min"], city["lat_max"])
    lon = uniform(city["lon_min"], city["lon_max"])

    res = {
        "city": city["name"],
        "lat": lat,
        "lng": lon,
    }

    print(res)
    return res