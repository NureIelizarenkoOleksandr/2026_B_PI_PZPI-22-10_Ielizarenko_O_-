import hashlib
from datetime import timedelta, datetime
from typing import Optional
from jose import JWTError, jwt

from fastapi import HTTPException, APIRouter, Depends
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel, field_validator
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from starlette import status

from app.api.core.config import settings
from app.db.session import get_db
from app.db.initial_models import User as db_user
from app.db.user_role import UserRole

router = APIRouter()

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/login")

ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30
SECRET_KEY=settings.SECRET_KEY

async def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db),
):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        email: str = payload.get("sub")
        if email is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Could not validate credentials",
                headers={"WWW-Authenticate": "Bearer"},
            )
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
    user = await get_user(db, email=email)
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return user


async def get_current_admin(current_user: db_user = Depends(get_current_user)) -> db_user:
    if current_user.role != UserRole.admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin access required",
        )
    return current_user


def create_access_token(data: dict, expires_delta: timedelta = None):
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


def decode_access_token(token: str):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")


class User(BaseModel):
    email: str
    username: Optional[str] = None
    role: UserRole

    model_config = {
        "from_attributes": True
    }

class UserInDB(User):
    password: str

    model_config = {
        "from_attributes": True
    }

class UserCreate(BaseModel):
    email: str
    password: str
    username: Optional[str] = None

    @field_validator("password")
    def hash_password(cls, v):
        return hashlib.sha256(v.encode()).hexdigest()


class MeOut(BaseModel):
    id: int
    email: str
    username: str
    role: UserRole

    model_config = {
        "from_attributes": True
    }

async def get_user(db: AsyncSession, email: str) -> db_user | None:
    result = await db.execute(select(db_user).where(db_user.email == email))
    return result.scalar_one_or_none()

def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()

def verify_password(password: str, hashed: str) -> bool:
    return hash_password(password) == hashed


async def authenticate_user(db: AsyncSession, email: str, password: str):
    user = await get_user(db, email=email)
    if not user or not verify_password(password, user.password):
        return None
    return user


@router.post("/register", status_code=201)
async def register_user(user: UserCreate, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(db_user).filter(db_user.email == user.email))
    existing_user = result.scalars().first()

    if existing_user:
        raise HTTPException(status_code=400, detail="User already exists")

    new_user = db_user(
        email=user.email,
        password=user.password,
        username=user.username or user.email,
        role=UserRole.user,
    )
    db.add(new_user)
    await db.commit()
    return {"msg": "User registered successfully"}

@router.post("/login")
async def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: AsyncSession = Depends(get_db),
):
    user = await authenticate_user(db, form_data.username, form_data.password)
    print("FOUND USER")
    print(user)
    if not user:
        raise HTTPException(status_code=401, detail="Incorrect email or password")

    access_token = create_access_token(data={"sub": user.email})
    return {"access_token": access_token, "token_type": "bearer"}

@router.get("/me", response_model=MeOut)
async def read_me(current_user: db_user = Depends(get_current_user)):
    return current_user


@router.get("/users/me", response_model=User)
def read_users_me(current_user: User = Depends(get_current_user)):
    return current_user