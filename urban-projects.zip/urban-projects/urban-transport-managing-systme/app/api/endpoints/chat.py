from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.endpoints.auth import get_current_admin, get_current_user
from app.api.shemas.chat import ChatConversationOut, SendChatMessageIn
from app.db.initial_models import User
from app.db.session import get_db
from app.db.user_role import UserRole
from app.services.chat import (
    get_admin_conversation,
    get_admin_conversations,
    get_user_conversation_with_admin,
    get_user_conversations,
    send_admin_message,
)

router = APIRouter()


@router.post("/messages", response_model=ChatConversationOut)
async def send_message_to_user(
    payload: SendChatMessageIn,
    db: AsyncSession = Depends(get_db),
    admin: User = Depends(get_current_admin),
):
    try:
        return await send_admin_message(
            db,
            admin=admin,
            user_id=payload.user_id,
            text=payload.text,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("/conversations/{other_id}", response_model=ChatConversationOut)
async def get_conversation(
    other_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Open one conversation.

    - If current user is ADMIN: `other_id` is the recipient user_id.
    - If current user is NOT admin: `other_id` is the admin_id.
    """
    if current_user.role == UserRole.admin:
        conversation = await get_admin_conversation(db, admin_id=current_user.id, user_id=other_id)
        admin_id = current_user.id
        user_id = other_id
    else:
        conversation = await get_user_conversation_with_admin(db, user_id=current_user.id, admin_id=other_id)
        admin_id = other_id
        user_id = current_user.id

    if conversation is None:
        return ChatConversationOut(
            id=0,
            admin_id=admin_id,
            user_id=user_id,
            messages=[],
        )
    return conversation


@router.get("/my", response_model=list[ChatConversationOut])
async def get_my_conversations(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    # For regular users (drivers), "my" means inbox: conversations where user_id == me.
    # For admins, "my" means what I sent: conversations where admin_id == me.
    if current_user.role == UserRole.admin:
        return await get_admin_conversations(db, admin_id=current_user.id)
    return await get_user_conversations(db, user_id=current_user.id)
