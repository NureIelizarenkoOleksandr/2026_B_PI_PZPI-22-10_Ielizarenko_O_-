from pydantic import BaseModel

from app.db.user_role import UserRole


class UserOut(BaseModel):
    id: int
    email: str
    username: str
    role: UserRole

    model_config = {
        "from_attributes": True,
    }

