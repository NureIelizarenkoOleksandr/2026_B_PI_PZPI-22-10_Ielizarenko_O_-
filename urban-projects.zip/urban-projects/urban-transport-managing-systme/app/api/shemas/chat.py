from datetime import datetime

from pydantic import BaseModel, Field

from app.db.user_role import UserRole


class ChatMessageItem(BaseModel):
    sender_id: int
    sender_role: UserRole
    text: str
    sent_at: datetime


class SendChatMessageIn(BaseModel):
    user_id: int
    text: str = Field(min_length=1, max_length=4000)


class ChatConversationOut(BaseModel):
    id: int
    admin_id: int
    user_id: int
    messages: list[ChatMessageItem]

    model_config = {
        "from_attributes": True,
    }
