from typing import Any, Literal

from pydantic import BaseModel, Field

from app.db.user_role import UserRole


class WSConnectedOut(BaseModel):
    type: Literal["connected"] = "connected"
    group: str
    user_id: int
    role: UserRole
    connections_in_group: int


class WSMessageIn(BaseModel):
    text: str = Field(min_length=1, max_length=4000)


class WSMessageOut(BaseModel):
    type: Literal["message"] = "message"
    group: str
    sender_id: int
    sender_role: UserRole
    text: str


class WSErrorOut(BaseModel):
    type: Literal["error"] = "error"
    detail: str


class WSSystemOut(BaseModel):
    type: Literal["system"] = "system"
    detail: str
    data: dict[str, Any] | None = None
