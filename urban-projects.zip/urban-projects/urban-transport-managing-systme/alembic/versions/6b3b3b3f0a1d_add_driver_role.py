"""add driver role to userrole enum

Revision ID: 6b3b3b3f0a1d
Revises: f7g8h9i0j1k2
Create Date: 2026-07-13 20:53:00.000000

"""

from typing import Sequence, Union

from alembic import op


revision: str = "6b3b3b3f0a1d"
down_revision: Union[str, None] = "f7g8h9i0j1k2"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # PostgreSQL enum alteration (safe if already applied)
    op.execute("ALTER TYPE userrole ADD VALUE IF NOT EXISTS 'driver'")


def downgrade() -> None:
    # Downgrading enum values in Postgres is non-trivial; keep as no-op.
    pass

