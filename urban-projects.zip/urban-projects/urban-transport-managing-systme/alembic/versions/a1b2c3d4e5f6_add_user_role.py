"""add user role

Revision ID: a1b2c3d4e5f6
Revises: eeafec1868d5
Create Date: 2026-05-31 12:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "a1b2c3d4e5f6"
down_revision: Union[str, None] = "eeafec1868d5"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

user_role_enum = sa.Enum("user", "admin", name="userrole")


def upgrade() -> None:
    user_role_enum.create(op.get_bind(), checkfirst=True)
    op.add_column(
        "user",
        sa.Column("role", user_role_enum, nullable=False, server_default="user"),
    )


def downgrade() -> None:
    op.drop_column("user", "role")
    user_role_enum.drop(op.get_bind(), checkfirst=True)
